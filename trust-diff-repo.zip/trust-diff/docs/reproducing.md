# Reproducing the figures

Wall-clock times are for a single modern CPU core; nothing here needs a GPU.

```bash
export TRUSTDIFF_DATA=/path/to/data          # optional
python -m trustdiff run --scene both         # ~9 min, writes results/{houston,pavia}.pkl
python -m trustdiff sweep-zeta               # ~12 min
python -m trustdiff sweep-params             # ~20 min
python -m trustdiff runtime                  # ~6 min
python -m trustdiff classify                 # ~8 min
python -m trustdiff capture                  # ~4 min, writes results/schematics.pkl
python -m trustdiff figures --which schematics
python -m trustdiff figures --which all
```

`run` caches the reconstruction of every variant for both scenes; the figure
commands read those caches, so re-rendering a figure after a style change costs
seconds rather than minutes.

## Determinism

Every stochastic element is seeded: the case builder takes `seed`, the sampler
takes `seed`, and the figures that draw a random subset of correspondences take
their own. Repeating a command on the same machine reproduces the arrays
bit for bit. Across machines, BLAS differences move the last digit of the
reported metrics.

## What the numbers mean

The figures are produced in the reduced setting described in the README and in
Sect. 5.5.3 of the article: a guided-filter prior stands in for the frozen ADM
checkpoint, and hand-crafted descriptors stand in for the trained encoder. The
reference gain is negative in this setting, which the figures state on their
faces. The trust behaviour — abstention, the reliability map, the hallucination
score — reproduces without any training, and that is what these figures are
evidence for.
