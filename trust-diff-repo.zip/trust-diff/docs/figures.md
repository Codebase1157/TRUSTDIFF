# Figure map

Files are named for the figure number they carry in the article.

| Article | Key for `--which` | File | Produced by |
| --- | --- | --- | --- |
| Fig. 1 | `schematics` | `fig01_overview` | `schematics.fig01` |
| Fig. 2 | `schematics` | `fig02_matching` | `schematics.fig02` |
| Fig. 3 | `schematics` | `fig03_training` | `schematics.fig03` |
| Fig. 4 | `fig04` | `fig04_cnc_construction` | `render.construction_figure` |
| Fig. 5 | `fig05` | `fig05_houston_qualitative` | `render.qualitative_figure` |
| Fig. 6 | `fig06` | `fig06_pavia_qualitative` | `render.qualitative_figure` |
| Fig. 7 | `fig07` | `fig07_spectral_fidelity` | `render.spectral_figure` |
| Fig. 8 | `fig08` | `fig08_cnc_sweep` | `render.zeta_figure` |
| Fig. 9 | `fig09` | `fig09_reliability` | `render.reliability_figure` |
| Fig. 10 | `fig10` | `fig10_ablation` | `render.ablation_figure` |
| Fig. 11 | `fig11` | `fig11_correspondence` | `render.correspondence_figure` |
| Fig. 12 | — | — | supplied by the authors; not generated here |
| Fig. 13 | `fig13` | `fig13_parameters` | `render.param_figure` |
| Fig. 14 | `fig14` | `fig14_runtime` | `render.runtime_figure` |
| Fig. 15 | `fig15` | `fig15_classification` | `render.classify_figure` |

Every figure is written as both `.png` at 600 dpi and `.pdf`.

Figs. 1-3 are drawn by `schematics.py` under a stricter rule than the result
figures: all lettering is black, colour is carried only by data, and every
coloured element is also named in words, so the figures survive a greyscale
print. The image panels in them are real arrays captured from a real run by
`capture.py`, not mock-ups.
