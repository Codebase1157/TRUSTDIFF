"""The invariances the matcher is built on, and the gradient it descends.

The last two tests are regression tests.  An extra negation in grad_adjoint
once made the reference guidance ascend its own energy; every reconstruction
metric still looked plausible, and only a finite-difference check caught it.
"""
import numpy as np
import pytest

from trustdiff import matching as M, solver


def stripes(shape=(64, 64), angle=0.3, freq=0.08, amp=1.0, offset=0.0):
    """A pattern whose gradient points along `angle`, measured from +y towards
    +x, which is the convention the structure tensor uses."""
    yy, xx = np.mgrid[0:shape[0], 0:shape[1]].astype(float)
    t = np.cos(angle) * yy + np.sin(angle) * xx
    return amp * np.sin(2 * np.pi * freq * t) + offset


def toy(seed):
    """A small, well-conditioned instance of the reference energy."""
    rng = np.random.default_rng(seed)
    k, C, c, H, W = 3, 8, 2, 16, 16
    U = rng.standard_normal((k, H, W)) * 0.1
    E = np.linalg.qr(rng.standard_normal((C, k)))[0]
    R = np.abs(rng.standard_normal((c, C)))
    R /= R.sum(1, keepdims=True)
    S = np.zeros((3 * c, H, W))
    for b in range(c):
        S[3 * b] = 1.0                    # identity tensor field
        S[3 * b + 2] = 1.0
    return U, E, R, S, np.full((H, W), 0.7), np.ones((H, W))


def test_structure_tensor_recovers_the_orientation():
    for angle in (0.0, 0.3, 1.0, -0.7):
        th = M.structure_tensor_orientation(stripes(angle=angle), sigma=2.0)
        inner = th[8:-8, 8:-8]
        d = np.angle(np.exp(2j * (inner - angle))) / 2     # theta is mod pi
        assert np.abs(d).mean() < 0.02, angle


def test_normalised_gradient_is_contrast_invariant():
    """psi keeps its direction under any positive affine change of intensity;
    eta only damps flat areas."""
    I = stripes()
    gy1, gx1 = M.normalized_gradient(I, eta=1e-6)
    gy2, gx2 = M.normalized_gradient(3.7 * I + 0.42, eta=1e-6)
    inner = (slice(4, -4), slice(4, -4))
    assert (gy1 * gy2 + gx1 * gx2)[inner].min() > 0.999


def test_normalised_gradient_is_bounded():
    rng = np.random.default_rng(0)
    gy, gx = M.normalized_gradient(rng.standard_normal((40, 40)))
    assert np.max(gy ** 2 + gx ** 2) <= 1.0 + 1e-12


def test_grad_adjoint_is_the_adjoint_of_the_gradient():
    """<grad I, v> == <I, grad_adjoint v> for every I and v, boundary rows
    included.  This is the identity the guidance step relies on."""
    rng = np.random.default_rng(1)
    for shape in ((17, 23), (32, 32)):
        I = rng.standard_normal(shape)
        vy = rng.standard_normal(shape)
        vx = rng.standard_normal(shape)
        gy = np.zeros_like(I); gx = np.zeros_like(I)
        gy[1:-1] = 0.5 * (I[2:] - I[:-2])
        gy[0] = I[1] - I[0]; gy[-1] = I[-1] - I[-2]
        gx[:, 1:-1] = 0.5 * (I[:, 2:] - I[:, :-2])
        gx[:, 0] = I[:, 1] - I[:, 0]; gx[:, -1] = I[:, -1] - I[:, -2]
        lhs = float(np.sum(gy * vy + gx * vx))
        rhs = float(np.sum(I * M.grad_adjoint(vy, vx)))
        assert lhs == pytest.approx(rhs, rel=1e-10, abs=1e-10)


def test_reference_energy_gradient_matches_finite_differences():
    """ref_energy_grad must return the gradient of the energy it reports."""
    U, E, R, S, mp, good = toy(2)
    g = solver.ref_energy_grad(U, E, R, S, mp, good)[0]
    rng = np.random.default_rng(11)
    d = rng.standard_normal(U.shape)
    d /= np.linalg.norm(d)
    h = 1e-5
    up = solver.ref_energy_grad(U + h * d, E, R, S, mp, good)[1]
    dn = solver.ref_energy_grad(U - h * d, E, R, S, mp, good)[1]
    numeric = (up - dn) / (2 * h)
    analytic = float(np.sum(g * d))
    assert analytic == pytest.approx(numeric, rel=5e-3,
                                     abs=1e-4 * max(abs(numeric), 1.0))


def test_a_step_against_the_gradient_lowers_the_energy():
    U, E, R, S, mp, good = toy(3)
    g, e0 = solver.ref_energy_grad(U, E, R, S, mp, good)
    step = 1e-3 * np.linalg.norm(U) / (np.linalg.norm(g) + 1e-30)
    e1 = solver.ref_energy_grad(U - step * g, E, R, S, mp, good)[1]
    assert e1 < e0


def test_reliability_weight_scales_the_gradient():
    """A pixel with zero reliability must not contribute to the guidance."""
    U, E, R, S, mp, good = toy(4)
    mp0 = np.zeros_like(mp)
    g0, e0 = solver.ref_energy_grad(U, E, R, S, mp0, good)
    assert np.abs(g0).max() == 0.0
    assert e0 == pytest.approx(0.0, abs=1e-12)
