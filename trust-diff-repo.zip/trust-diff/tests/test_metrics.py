"""The reported measures, on inputs whose answer is known in closed form."""
import numpy as np
import pytest

from trustdiff import metrics


def test_psnr_on_a_known_error():
    rng = np.random.default_rng(0)
    gt = rng.random((4, 16, 16))
    assert metrics.psnr(gt + 0.1, gt) == pytest.approx(20.0, abs=1e-6)


def test_psnr_is_restricted_by_the_mask():
    gt = np.zeros((2, 8, 8))
    z = np.zeros((2, 8, 8))
    mask = np.zeros((8, 8), bool)
    mask[:4] = True
    z[:, 4:] = 0.5                      # error only outside the mask
    assert metrics.psnr(z, gt, mask) > 250


def test_sam_is_zero_for_scaled_spectra():
    """SAM ignores a per-pixel gain by construction.  The tolerance is loose
    because arccos is ill-conditioned at 1: in float64 an angle of exactly zero
    is recovered to about 1e-4 degrees, not to machine epsilon."""
    rng = np.random.default_rng(1)
    gt = rng.random((10, 8, 8)) + 0.1
    assert metrics.sam(2.5 * gt, gt) == pytest.approx(0.0, abs=1e-3)


def test_sam_is_ninety_degrees_for_orthogonal_spectra():
    gt = np.zeros((2, 4, 4)); gt[0] = 1.0
    z = np.zeros((2, 4, 4)); z[1] = 1.0
    assert metrics.sam(z, gt) == pytest.approx(90.0, abs=1e-6)


def test_rmse_and_cc_on_an_exact_reconstruction():
    rng = np.random.default_rng(2)
    gt = rng.random((5, 8, 8))
    assert metrics.rmse(gt, gt) == pytest.approx(0.0, abs=1e-12)
    assert metrics.cc(gt, gt) == pytest.approx(1.0, abs=1e-8)


def test_ergas_scales_with_the_ratio():
    rng = np.random.default_rng(3)
    gt = rng.random((5, 8, 8)) + 0.5
    z = gt + 0.05
    assert metrics.ergas(z, gt, 8) == pytest.approx(
        metrics.ergas(z, gt, 4) / 2.0, rel=1e-8)


def test_rih_is_zero_when_the_reference_changes_nothing():
    rng = np.random.default_rng(4)
    z = rng.random((4, 8, 8))
    mask = np.zeros((8, 8), bool); mask[2:6, 2:6] = True
    assert metrics.rih(z, z, mask) == pytest.approx(0.0, abs=1e-12)


def test_rih_is_never_negative_and_grows_with_the_change():
    rng = np.random.default_rng(5)
    z0 = rng.random((4, 8, 8)) + 1.0
    mask = np.ones((8, 8), bool)
    vals = [metrics.rih(z0 + d, z0, mask) for d in (0.0, 0.05, 0.2)]
    assert vals[0] == 0.0
    assert vals[0] < vals[1] < vals[2]


def test_ece_is_small_for_a_calibrated_map():
    """A map whose value equals the empirical frequency in every bin has
    almost no calibration error; what is left is sampling noise."""
    rng = np.random.default_rng(6)
    ps = (0.05, 0.35, 0.65, 0.95)
    m = np.repeat(np.array(ps), 2000)
    y = np.concatenate([(rng.random(2000) < p).astype(float) for p in ps])
    e, curve = metrics.ece(m, y, bins=10)
    assert e < 0.02
    assert len(curve) == 10


def test_summarise_returns_the_reported_set():
    rng = np.random.default_rng(7)
    gt = rng.random((4, 16, 16))
    nc = np.zeros((16, 16), bool); nc[8:] = True
    d = metrics.summarise(gt + 0.01, gt, 4, nc)
    assert set(d) == {"PSNR", "SSIM", "SAM", "ERGAS", "CC", "RMSE",
                      "PSNR_valid", "PSNR_nc"}
    assert all(np.isfinite(v) for v in d.values())
