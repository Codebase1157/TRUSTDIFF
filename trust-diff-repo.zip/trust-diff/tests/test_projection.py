"""Proposition 1: the range-null projection reproduces the observation exactly.

The trustworthiness argument of the article depends on the reference being
unable to touch what the low-resolution measurement already determines.  That
is a property of the projection, so it is tested directly rather than inferred
from a reconstruction metric.
"""
import numpy as np
import pytest

from trustdiff import ops


# The projection is exact up to the conjugate-gradient solve inside A^+.  The
# tests below tighten that solve so they measure the projection itself rather
# than the sampler's speed/accuracy trade-off; TOL is the residual that leaves.
TOL = 1e-8


def make(rng, k=5, H=32, ratio=4):
    d = ops.Degradation((H, H), ratio)
    xs = rng.standard_normal((k, H // ratio, H // ratio))

    def project(u, lam=1.0):
        return u + lam * d.Aplus(xs - d.A(u), iters=400, tol=1e-14)

    return d, xs, project


def test_projection_reproduces_the_observation():
    rng = np.random.default_rng(1)
    d, xs, project = make(rng)
    u = rng.standard_normal((5, 32, 32))
    assert np.abs(d.A(project(u)) - xs).max() < TOL


def test_projection_is_idempotent():
    rng = np.random.default_rng(2)
    d, xs, project = make(rng)
    u = rng.standard_normal((5, 32, 32))
    p1 = project(u)
    assert np.abs(project(p1) - p1).max() < TOL


def test_reference_can_only_move_the_null_space():
    """Corollary 1: whatever the guidance does to u, the observation that comes
    back out of the projection is unchanged."""
    rng = np.random.default_rng(3)
    d, xs, project = make(rng)
    u = project(rng.standard_normal((5, 32, 32)))
    for scale in (0.01, 1.0, 100.0):
        perturbed = project(u + scale * rng.standard_normal(u.shape))
        assert np.abs(d.A(perturbed) - xs).max() < TOL


def test_relaxed_projection_trades_consistency_for_noise():
    """lambda < 1 is the noise-robust variant: it leaves a strictly larger
    consistency error than the exact projection, shrinking towards it as
    lambda approaches one."""
    rng = np.random.default_rng(4)
    d, xs, project = make(rng)
    u = rng.standard_normal((5, 32, 32))
    errs = [float(np.linalg.norm(d.A(project(u, lam)) - xs))
            for lam in (0.8, 0.95, 1.0)]
    assert errs[0] > errs[1] > errs[2]
    assert errs[2] < TOL


def test_spectral_subspace_is_orthonormal_and_ordered():
    rng = np.random.default_rng(5)
    x = rng.standard_normal((20, 16, 16))
    e, s = ops.spectral_subspace(x, k=6)
    assert e.shape == (20, 6)
    np.testing.assert_allclose(e.T @ e, np.eye(6), atol=1e-10)
    assert np.all(np.diff(s) <= 1e-12)
