"""The degradation operator and its adjoint.

Everything the sampler does rests on A being the operator the data were
generated with, and on AT being its true adjoint: the range-null projection is
built from A^+ = A^T (A A^T)^{-1}, so an adjoint that is merely approximate
would silently break Proposition 1.
"""
import numpy as np
import pytest

from trustdiff import ops, prep


@pytest.fixture
def rng():
    return np.random.default_rng(0)


def test_forward_matches_the_wald_protocol(rng):
    """prep.wald_degrade generates the data; ops.Degradation.A is what the
    sampler inverts.  They must be the same operator, not merely similar."""
    hr = rng.random((4, 64, 64))
    for ratio in (2, 4):
        d = ops.Degradation(hr.shape[1:], ratio)
        np.testing.assert_allclose(d.A(hr), prep.wald_degrade(hr, ratio),
                                   rtol=0, atol=1e-12)


def test_adjoint_is_an_adjoint(rng):
    d = ops.Degradation((32, 32), 4)
    for _ in range(5):
        u = rng.standard_normal((3, 32, 32))
        x = rng.standard_normal((3, 8, 8))
        lhs = float(np.sum(d.A(u) * x))
        rhs = float(np.sum(u * d.AT(x)))
        assert lhs == pytest.approx(rhs, rel=1e-10, abs=1e-10)


def test_pseudo_inverse_right_inverts(rng):
    """A A^+ = I on the observation space, to the tolerance of the conjugate
    gradient solve that computes A^+.  The default stops at a relative squared
    residual of 1e-10, which is about 1e-5 in absolute terms."""
    d = ops.Degradation((32, 32), 4)
    x = rng.standard_normal((3, 8, 8))
    assert np.abs(d.A(d.Aplus(x)) - x).max() < 1e-4


def test_pseudo_inverse_converges_when_asked_to(rng):
    """The residual above is the solver's stopping rule, not a limit of the
    operator: tightening the tolerance drives it to round-off."""
    d = ops.Degradation((32, 32), 4)
    x = rng.standard_normal((3, 8, 8))
    loose = np.abs(d.A(d.Aplus(x, tol=1e-8)) - x).max()
    tight = np.abs(d.A(d.Aplus(x, iters=400, tol=1e-14)) - x).max()
    assert tight < 1e-12 < loose


def test_pseudo_inverse_lands_in_the_row_space(rng):
    """A^+ x is orthogonal to the null space of A, so re-projecting it changes
    nothing."""
    d = ops.Degradation((32, 32), 4)
    x = rng.standard_normal((2, 8, 8))
    u = d.Aplus(x, iters=400, tol=1e-14)
    assert np.abs(d.Aplus(d.A(u), iters=400, tol=1e-14) - u).max() < 1e-8


def test_psf_width_matches_the_ratio():
    """The Wald protocol asks for a Gaussian whose full width at half maximum
    is the spatial ratio."""
    for r in (2, 3, 4, 8):
        sigma = prep.gaussian_psf_sigma(r)
        fwhm = 2.0 * np.sqrt(2.0 * np.log(2.0)) * sigma
        assert fwhm == pytest.approx(r)
