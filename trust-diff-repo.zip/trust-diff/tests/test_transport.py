"""The unbalanced coupling, which is where abstention comes from.

tau is the mass-abstention parameter.  The article's claim is that lowering it
makes the plan keep mass rather than spend it on a bad match, and that raising
it recovers the balanced problem in which every region must be matched.  Both
are testable on a small synthetic problem whose answer is known.
"""
import numpy as np

from trustdiff import matching as M


def problem(n=12, bad=3):
    """n regions, each with one cheap partner, except the last `bad`, whose
    every candidate is expensive: the situation a changed region is in."""
    C = np.full((n, n), 0.9)
    for i in range(n):
        C[i, i] = 0.02
    for i in range(n - bad, n):
        C[i, :] = 0.95
    a = np.full(n, 1.0 / n)
    b = np.full(n, 1.0 / n)
    mask = np.ones((n, n), bool)
    return C, a, b, mask


def run(tau, mask=None):
    C, a, b, m = problem()
    if mask is not None:
        m = mask
    G = M.fugw(C, a, b, m, None, None, None, None, None, None,
               alpha=0.0, eps=0.05, tau=tau, n_outer=1, n_sink=300)
    return G, a


def test_cheap_pairs_win():
    G, _ = run(tau=10.0)
    assert np.all(np.argmax(G[:9], axis=1) == np.arange(9))


def test_lower_tau_keeps_more_mass():
    """Dustbin mass grows monotonically as abstention gets cheaper."""
    kept = []
    for tau in (2.0, 0.5, 0.15, 0.05):
        G, a = run(tau)
        kept.append(float(np.maximum(a - G.sum(1), 0).sum()))
    assert all(x < y for x, y in zip(kept, kept[1:])), kept


def test_expensive_rows_abstain_first():
    """The rows with no cheap partner keep a larger share of their mass than
    the rows that have one."""
    G, a = run(tau=0.15)
    frac = np.maximum(a - G.sum(1), 0) / a
    assert frac[-3:].min() > frac[:9].max()


def test_large_tau_approaches_the_balanced_plan():
    G, a = run(tau=1e4)
    assert np.abs(G.sum(1) - a).max() < 2e-3


def test_reliability_is_a_probability_and_ranks_correctly():
    G, a = run(tau=0.15)
    m, pi, r = M.reliability(G, a)
    assert m.min() >= 0.0 and m.max() <= 1.0
    assert m[-3:].max() < m[:9].min()
    np.testing.assert_allclose(pi.sum(1), 1.0, atol=1e-8)


def test_plan_never_leaves_the_candidate_set():
    C, a, b, mask = problem()
    mask[:, 5] = False                      # column 5 is not a candidate
    G, _ = run(tau=0.15, mask=mask)
    assert G[:, 5].max() == 0.0
