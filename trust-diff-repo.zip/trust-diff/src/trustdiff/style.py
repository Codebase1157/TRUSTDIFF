"""Figure styling for IEEE TGRS.

Colour follows the validated palette in the dataviz skill: categorical slots 1-3
(blue #2a78d6, orange #eb6834, aqua #1baf7a) -- the three-slot set that passes
the all-pairs CVD and normal-vision floors -- and one-hue sequential ramps, the
first in blue and the second in orange, never a rainbow.  Identity is never
carried by colour alone: every ROI box and every series is directly labelled.
"""
import matplotlib as mpl
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap

SURFACE = "#fcfcfb"
INK = "#0b0b0b"
INK2 = "#52514e"
MUTED = "#8a8985"

CAT = ["#2a78d6", "#eb6834", "#1baf7a"]          # slots 1-3, all-pairs validated
BLUE, ORANGE, AQUA = CAT

# one-hue sequential ramps, lightest step recedes toward the surface
BLUE_STEPS = ["#fcfcfb", "#cde2fb", "#b7d3f6", "#9ec5f4", "#86b6ef", "#6da7ec",
              "#5598e7", "#3987e5", "#2a78d6", "#256abf", "#1c5cab", "#184f95",
              "#104281", "#0d366b"]
ORANGE_STEPS = ["#fcfcfb", "#fde3d6", "#fbd0ba", "#f9bb9c", "#f7a47d", "#f48d5e",
                "#f07845", "#eb6834", "#d95926", "#c24b1d", "#a63f18", "#8a3413",
                "#6d280e", "#521d0a"]

SEQ_BLUE = LinearSegmentedColormap.from_list("seq_blue", BLUE_STEPS)
SEQ_ORANGE = LinearSegmentedColormap.from_list("seq_orange", ORANGE_STEPS)
BINARY = LinearSegmentedColormap.from_list("binary_nc", ["#eceae4", "#2d2d2b"])


def use():
    mpl.rcParams.update({
        "figure.facecolor": SURFACE,
        "savefig.facecolor": SURFACE,
        "axes.facecolor": SURFACE,
        "font.family": "DejaVu Sans",
        "font.size": 7.0,
        "axes.labelsize": 7.5,
        "axes.titlesize": 7.5,
        "xtick.labelsize": 6.5,
        "ytick.labelsize": 6.5,
        "legend.fontsize": 6.5,
        "axes.edgecolor": MUTED,
        "axes.linewidth": 0.6,
        "text.color": INK,
        "axes.labelcolor": INK,
        "xtick.color": INK2,
        "ytick.color": INK2,
        "axes.grid": True,
        "grid.color": "#e6e5e0",
        "grid.linewidth": 0.5,
        "axes.spines.top": False,
        "axes.spines.right": False,
        "lines.linewidth": 1.6,
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
    })


def bare(ax):
    ax.set_xticks([]); ax.set_yticks([]); ax.grid(False)
    for s in ax.spines.values():
        s.set_visible(True); s.set_color("#d8d7d2"); s.set_linewidth(0.5)
    return ax
