"""TRUST-Diff: partial-correspondence posterior diffusion for unpaired
reference-based hyperspectral image super-resolution.

Public entry points:

    from trustdiff import cases, solver, pcm, metrics
    case = cases.houston_case(zeta=0.25)
    out = solver.sample(case, mode="trust")

The command line is documented in the README:

    python -m trustdiff --help
"""
__version__ = "1.0.0"

from . import paths  # noqa: F401

__all__ = ["paths"]
