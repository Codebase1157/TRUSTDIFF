"""Run every variant on both scenes and cache the arrays the figures need."""
import os
import pickle
import time

import numpy as np
from scipy.ndimage import zoom
from sklearn.metrics import roc_auc_score

from . import cases
from . import metrics
from . import pcm
from . import solver
from .paths import OUT


VARIANTS = [
    ("bicubic",  "Bicubic"),
    ("noref",    "No-reference (A0)"),
    ("argmax",   "Argmax match,\nalways transfer"),
    ("softattn", "Soft attention,\nalways transfer"),
    ("balanced", "Balanced FUGW\n(tau -> inf)"),
    ("trust",    "TRUST-Diff\n(FUGW + reliability)"),
]

CFG = dict(T=40, M_refresh=13, eta_guide=0.03, tau=0.15, alpha=0.5, kc=24,
           geo_radius=60.0, n_seg_t=1100, n_seg_y=2600, k=8)


def run_scene(builder, tag, **over):
    cfg = dict(CFG); cfg.update(over)
    c = builder()
    hr = c["hr"].astype(np.float64)
    nc = c["nc"]
    ry, rx, _, _ = c["ref_rect"]

    t0 = time.time()
    refg = pcm.ReferenceGraph(c["y"].astype(np.float64), origin=(ry, rx),
                              n_segments=cfg["n_seg_y"])
    print(f"[{tag}] reference pyramid: {refg.n} nodes, {time.time()-t0:.0f}s", flush=True)

    res, mets = {}, {}
    res["bicubic"] = np.clip(np.stack([zoom(b, c["ratio"], order=3)
                                       for b in c["lr"].astype(np.float64)]), 0, 1)

    base = solver.sample(c, mode="noref", T=cfg["T"], k=cfg["k"])
    res["noref"] = base["Z"]
    eLR = {"noref": base["eLR"]}

    for mode in ["argmax", "softattn", "balanced", "trust"]:
        t0 = time.time()
        r = solver.sample(c, mode=mode, refg=refg,
                          T=cfg["T"], M_refresh=cfg["M_refresh"],
                          eta_guide=cfg["eta_guide"], tau=cfg["tau"],
                          alpha=cfg["alpha"], kc=cfg["kc"],
                          geo_radius=cfg["geo_radius"], n_seg_t=cfg["n_seg_t"],
                          k=cfg["k"])
        res[mode] = r["Z"]
        eLR[mode] = r["eLR"]
        if "m" in r:
            res[mode + "_m"] = r["m"]
            res[mode + "_pcm"] = r["pcm"]
        print(f"[{tag}] {mode}: {time.time()-t0:.0f}s", flush=True)

    for key, _ in VARIANTS:
        m = metrics.summarise(res[key], hr, c["ratio"], nc)
        m["eLR"] = eLR.get(key, np.nan)
        if key not in ("bicubic", "noref"):
            m["RIH"] = metrics.rih(res[key], res["noref"], nc)
            m["RG"] = m["PSNR"] - mets["noref"]["PSNR"]
            mm = res.get(key + "_m")
            if mm is not None:
                m["AUROC"] = float(roc_auc_score((~nc).ravel(), mm.ravel()))
                e, curve = metrics.ece(mm, ~nc)
                m["ECE"] = e
                m["calib"] = curve
        mets[key] = m
        print(f"[{tag}] {key:9s} PSNR {m['PSNR']:.2f}  valid {m['PSNR_valid']:.2f}  "
              f"nc {m['PSNR_nc']:.2f}  SAM {m['SAM']:.2f}  "
              f"RIH {m.get('RIH', float('nan')):.4f}  AUROC {m.get('AUROC', float('nan')):.3f}",
              flush=True)

    with open(f"{OUT}/{tag}.pkl", "wb") as f:
        pickle.dump(dict(case=c, res=res, met=mets, cfg=cfg), f)
    return c, res, mets


def main(argv=None):
    from .paths import ensure
    ensure()
    import sys
    argv = sys.argv[1:] if argv is None else list(argv)
    which = argv[0] if argv else "both"
    if which in ("both", "houston"):
        run_scene(cases.houston_case, "houston")
    if which in ("both", "pavia"):
        run_scene(cases.pavia_case, "pavia")


if __name__ == "__main__":
    main()
