"""Command line for the experiments and the figures.

    python -m trustdiff run        --scene houston
    python -m trustdiff sweep-zeta
    python -m trustdiff classify
    python -m trustdiff runtime
    python -m trustdiff capture
    python -m trustdiff figures    --which all
"""
import argparse
import sys

from . import paths


def main(argv=None):
    p = argparse.ArgumentParser(prog="trustdiff", description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = p.add_subparsers(dest="cmd", required=True)

    r = sub.add_parser("run", help="run every variant on a scene and cache the arrays")
    r.add_argument("--scene", choices=["houston", "pavia", "both"], default="both")

    sub.add_parser("sweep-zeta", help="CNC-Bench sweep over the non-correspondence fraction")
    sub.add_parser("sweep-params", help="sensitivity to k, T, epsilon and tau")
    sub.add_parser("classify", help="downstream classification on Indian Pines")
    sub.add_parser("runtime", help="cost against reference size")
    sub.add_parser("capture", help="cache the intermediates the schematics need")

    f = sub.add_parser("figures", help="render figures")
    f.add_argument("--which", default="all",
                   help="all, schematics, or a space-separated list such as "
                        "'fig05 fig06'")

    a = p.parse_args(argv)
    paths.ensure()

    if a.cmd == "run":
        from . import run
        run.main([] if a.scene == "both" else [a.scene])
    elif a.cmd == "sweep-zeta":
        from . import sweep_zeta
        sweep_zeta.main()
    elif a.cmd == "sweep-params":
        from . import sweep_params
        sweep_params.main()
    elif a.cmd == "classify":
        from . import classify
        classify.main()
    elif a.cmd == "runtime":
        from . import runtime
        runtime.main()
    elif a.cmd == "capture":
        from . import capture
        capture.main()
    elif a.cmd == "figures":
        if a.which in ("schematics", "figs123"):
            from . import schematics
            schematics.main()
        else:
            from . import render
            render.main(a.which.split())
    return 0


if __name__ == "__main__":
    sys.exit(main())
