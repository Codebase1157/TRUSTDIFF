"""The three evaluation cases, cut from the public cubes of Sect. 5.1."""
import numpy as np
from . import prep

# Houston 2013 (CASI). Target: the University of Houston campus tile containing
# the stadium, the running track, parking lots and low buildings -- i.e. exactly
# the repeated-texture content that makes patch matching ambiguous (Sect. 1).
HOUSTON_TGT = (46, 620, 256, 256)
HOUSTON_REF = (0, 700, 349, 540)      # larger window, 69 % column overlap

# Pavia University (ROSIS). Target: the lower campus with car parks and blocks.
PAVIA_TGT = (330, 60, 256, 256)
PAVIA_REF = (120, 0, 400, 340)        # larger window, 74 % row overlap


def houston_case(seed=0, zeta=0.25, ratio=4):
    h, hwl = prep.load_houston()
    p, pwl = prep.load_pavia()
    return prep.build_case(
        "Houston", h, hwl, HOUSTON_TGT, HOUSTON_REF,
        unrelated_cube=p, unrelated_wl=pwl, unrelated_rect=(0, 0, 300, 340),
        ratio=ratio, zeta=zeta, warp_amp=3.0, seed=seed,
        srf_centres=(480.0, 560.0, 660.0, 830.0))


def pavia_case(seed=1, zeta=0.25, ratio=4):
    h, hwl = prep.load_houston()
    p, pwl = prep.load_pavia()
    return prep.build_case(
        "Pavia", p, pwl, PAVIA_TGT, PAVIA_REF,
        unrelated_cube=h, unrelated_wl=hwl, unrelated_rect=(40, 1100, 300, 400),
        ratio=ratio, zeta=zeta, warp_amp=2.5, seed=seed,
        srf_centres=(480.0, 560.0, 660.0, 830.0))


# Indian Pines (AVIRIS). The whole scene is 145 x 145, far too small to carry a
# 256^2 target plus a larger disjoint reference, so it is not used as a
# super-resolution dataset. It carries complete 16-class labels, which makes it
# the right scene for the downstream-classification experiment. The reference is
# the same area under a warp, a fresh radiometric draw and replacement blobs:
# a full-overlap CNC-Bench instance rather than any regime of Table II.
INDIAN_TGT = (0, 0, 144, 144)
INDIAN_REF = (0, 0, 144, 144)


def indian_case(seed=3, zeta=0.25, ratio=4):
    h, hwl = prep.load_houston()
    ip, ipwl, gt = prep.load_indian()
    c = prep.build_case(
        "IndianPines", ip, ipwl, INDIAN_TGT, INDIAN_REF,
        unrelated_cube=h, unrelated_wl=hwl, unrelated_rect=(40, 1100, 200, 200),
        ratio=ratio, zeta=zeta, warp_amp=2.0, seed=seed,
        srf_centres=(480.0, 560.0, 660.0, 830.0))
    c["gt_labels"] = gt[:INDIAN_TGT[2], :INDIAN_TGT[3]].copy()
    return c
