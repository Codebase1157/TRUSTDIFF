"""The result figures of the article, Figs. 4-11 and 13-15.

Each is computed end to end from the public cubes named in Sect. 5.1, under the
degradation protocol of that section, and every value printed on a figure is
measured on that run.  Output file names carry the article's figure numbers;
see docs/figures.md."""
import os
import pickle

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.gridspec import GridSpec
from matplotlib.patches import Rectangle
from scipy.ndimage import gaussian_filter, uniform_filter
from sklearn.metrics import roc_curve, roc_auc_score

from . import metrics
from . import style
from .run import OUT, VARIANTS
from .paths import FIG, OUT


style.use()


# --------------------------------------------------------------------- helpers
def load(tag):
    with open(f"{OUT}/{tag}.pkl", "rb") as f:
        return pickle.load(f)


def falsecolour(cube, wl=None, bands=None, p=(2, 98)):
    if bands is None:
        idx = lambda t: int(np.argmin(np.abs(wl - t)))
        bands = (idx(660), idx(560), idx(480))
    im = np.stack([cube[b] for b in bands], -1).astype(float)
    lo, hi = np.percentile(im, p[0]), np.percentile(im, p[1])
    return np.clip((im - lo) / max(hi - lo, 1e-8), 0, 1)


def pick_rois(case, size=64):
    """One ROI where the reference is valid and one where it is not.  Both are
    chosen for texture content (local standard deviation of the ground truth)
    so that the zooms actually show structure, and both are required to be
    almost pure in their respective mask."""
    nc = case["nc"]
    lum = case["hr"].mean(0)
    loc_mean = uniform_filter(lum, size)
    loc_var = np.maximum(uniform_filter(lum ** 2, size) - loc_mean ** 2, 0)
    texture = np.sqrt(loc_var)
    # keep saturated / anomalous pixels out of the zooms: a single clipped
    # stripe would set the residual colour scale for the whole row
    hot = uniform_filter((case["hr"].max(0) > 0.985).astype(float), size)
    texture = np.where(hot > 1e-4, -1.0, texture)
    valid = uniform_filter((~nc).astype(float), size)
    inval = uniform_filter(nc.astype(float), size)
    H, W = lum.shape
    h = size // 2
    box = np.zeros_like(texture, bool)
    box[h + 3:H - h - 3, h + 3:W - h - 3] = True
    out = []
    for m in (valid, inval):
        ok = box & (m > 0.97)
        if not ok.any():
            ok = box & (m > 0.90)
        s_ = np.where(ok, texture, -1)
        y, x = np.unravel_index(int(np.argmax(s_)), s_.shape)
        out.append((int(y - h), int(x - h), size))
    return out


def draw_roi(ax, roi, colour, label=None):
    y, x, s = roi
    ax.add_patch(Rectangle((x, y), s, s, fill=False, ec="white", lw=1.6))
    ax.add_patch(Rectangle((x, y), s, s, fill=False, ec=colour, lw=0.9))
    if label:
        ax.text(x + 1, y - 2, label, color=colour, fontsize=5.2, fontweight="bold",
                ha="left", va="bottom",
                path_effects=[])


def crop(im, roi):
    y, x, s = roi
    return im[y:y + s, x:x + s]


# ------------------------------------------------------------- Figs. 5 and 6
def qualitative_figure(tag, out_name):
    d = load(tag)
    case, res, met = d["case"], d["res"], d["met"]
    hr = case["hr"].astype(np.float64)
    wl = case["wl"]
    nc = case["nc"]
    roi_v, roi_i = pick_rois(case)

    keys = [k for k, _ in VARIANTS]
    cols = ["Ground truth"] + [n for _, n in VARIANTS]

    resid = {k: np.abs(res[k] - hr).mean(0) for k in keys}
    vmax = float(np.percentile(np.stack(list(resid.values())), 98.5))
    vmax_roi = float(np.percentile(np.stack([crop(resid[k], roi_i) for k in keys]), 98.0))

    ncol = len(cols) + 1
    fig = plt.figure(figsize=(7.16, 5.28))
    gs = GridSpec(5, ncol, figure=fig, wspace=0.045, hspace=0.075,
                  width_ratios=[1] * len(cols) + [1.06],
                  left=0.046, right=0.968, top=0.936, bottom=0.050)

    idx = lambda t: int(np.argmin(np.abs(wl - t)))
    bands = (idx(660), idx(560), idx(480))
    rowlab = [("result", style.INK2), ("valid ROI", style.AQUA),
              ("invalid ROI", style.ORANGE), ("residual", style.INK2),
              ("residual,\ninvalid ROI", style.ORANGE)]

    for c, key in enumerate(["gt"] + keys):
        im = falsecolour(hr if key == "gt" else res[key], bands=bands)
        rr = np.abs((hr if key == "gt" else res[key]) - hr).mean(0)

        ax = style.bare(fig.add_subplot(gs[0, c]))
        ax.imshow(im)
        draw_roi(ax, roi_v, style.AQUA)
        draw_roi(ax, roi_i, style.ORANGE)
        ax.set_title(cols[c], fontsize=6.0, pad=2.4, linespacing=1.0)

        for row, (roi, col) in enumerate([(roi_v, style.AQUA), (roi_i, style.ORANGE)], start=1):
            ax = style.bare(fig.add_subplot(gs[row, c]))
            ax.imshow(crop(im, roi))
            for sp in ax.spines.values():
                sp.set_color(col); sp.set_linewidth(1.1)

        ax = style.bare(fig.add_subplot(gs[3, c]))
        if key == "gt":
            ax.imshow(np.zeros_like(hr[0]), cmap="Greys", vmin=0, vmax=1)
            ax.text(0.5, 0.5, "mean absolute\nresidual  $\\rightarrow$",
                    transform=ax.transAxes, ha="center", va="center",
                    fontsize=5.8, color=style.INK2)
        else:
            ax.imshow(rr, cmap=style.SEQ_ORANGE, vmin=0, vmax=vmax)
            draw_roi(ax, roi_i, style.ORANGE)

        ax = style.bare(fig.add_subplot(gs[4, c]))
        if key == "gt":
            ax.imshow(np.zeros((roi_i[2], roi_i[2])), cmap="Greys", vmin=0, vmax=1)
            ax.text(0.5, 0.5, "zoom of the\ninvalid ROI  $\\rightarrow$",
                    transform=ax.transAxes, ha="center", va="center",
                    fontsize=5.8, color=style.INK2)
        else:
            ax.imshow(crop(rr, roi_i), cmap=style.SEQ_ORANGE, vmin=0, vmax=vmax_roi)
            for sp in ax.spines.values():
                sp.set_color(style.ORANGE); sp.set_linewidth(1.1)
            m = met[key]
            txt = f"{m['PSNR']:.2f} dB"
            if "RIH" in m:
                txt += f" | RIH {m['RIH']:.3f}"
            ax.text(0.5, -0.05, txt, transform=ax.transAxes, ha="center", va="top",
                    fontsize=5.3, color=style.INK2)

    # row labels on the left margin
    for r, (lab, col) in enumerate(rowlab):
        axtmp = fig.add_subplot(gs[r, 0]); bb = axtmp.get_position(); axtmp.remove()
        fig.text(0.013, (bb.y0 + bb.y1) / 2, lab, rotation=90, va="center",
                 ha="center", fontsize=6.0, color=col, linespacing=1.0)

    # ---- side column: reference, reliability, true mask, colour bars
    sc = ncol - 1
    ax = style.bare(fig.add_subplot(gs[0, sc]))
    ax.imshow(falsecolour(case["y"], bands=(2, 1, 0)))
    ry, rx, rh, rw = case["ref_rect"]
    ty, tx, th, tw = case["tgt_rect"]
    ax.add_patch(Rectangle((tx - rx, ty - ry), tw, th, fill=False, ec="white", lw=1.4))
    ax.add_patch(Rectangle((tx - rx, ty - ry), tw, th, fill=False, ec=style.BLUE, lw=0.8))
    ax.set_title("unpaired reference $Y$", fontsize=6.0, pad=2.4)

    ax = style.bare(fig.add_subplot(gs[1, sc]))
    mm = res["trust_m"]
    ax.imshow(mm, cmap=style.SEQ_BLUE, vmin=0, vmax=1)
    a = met["trust"].get("AUROC", np.nan)
    ax.text(0.5, 1.025, f"reliability $m$   AUROC {a:.3f}", transform=ax.transAxes,
            ha="center", va="bottom", fontsize=6.0, color=style.INK)
    cax = ax.inset_axes([0.10, 0.045, 0.80, 0.045])
    cb = fig.colorbar(plt.cm.ScalarMappable(norm=plt.Normalize(0, 1), cmap=style.SEQ_BLUE),
                      cax=cax, orientation="horizontal")
    cb.set_ticks([0, 1]); cb.set_ticklabels(["0", "1"])
    cb.outline.set_linewidth(0.5); cb.outline.set_edgecolor("white")
    cb.ax.tick_params(labelsize=5.0, length=0, pad=1.2, colors="white")

    ax = style.bare(fig.add_subplot(gs[2, sc]))
    ax.imshow(nc.astype(float), cmap=style.BINARY, vmin=0, vmax=1)
    ax.text(0.5, -0.035,
            f"true $\\Omega_{{nc}}$: {100*nc.mean():.0f} % of the tile\n"
            "(dark = no valid counterpart)",
            transform=ax.transAxes, ha="center", va="top", fontsize=5.5,
            color=style.INK, linespacing=1.3)

    for row, vm, lab in [(3, vmax, "residual scale,\nfull tile"),
                         (4, vmax_roi, "residual scale,\nROI zoom")]:
        axc = fig.add_subplot(gs[row, sc]); axc.set_axis_off()
        cax = axc.inset_axes([0.08, 0.42, 0.84, 0.12])
        cb = fig.colorbar(plt.cm.ScalarMappable(norm=plt.Normalize(0, vm),
                                                cmap=style.SEQ_ORANGE),
                          cax=cax, orientation="horizontal")
        cb.outline.set_linewidth(0.4); cb.outline.set_edgecolor(style.MUTED)
        cb.set_ticks([0, vm]); cb.set_ticklabels(["0", f"{vm:.3f}"])
        cb.ax.tick_params(labelsize=5.0, length=1.6, pad=0.8)
        axc.text(0.5, 0.60, lab, transform=axc.transAxes, ha="center", va="bottom",
                 fontsize=5.5, color=style.INK2, linespacing=1.2)

    fig.savefig(f"{FIG}/{out_name}.pdf")
    fig.savefig(f"{FIG}/{out_name}.png", dpi=600)
    plt.close(fig)
    return dict(roi_valid=roi_v, roi_invalid=roi_i, vmax=vmax, vmax_roi=vmax_roi)


# ----------------------------------------------------- Fig. 10: spectral fidelity
SPEC_METHODS = [("bicubic", "Bicubic", style.BLUE, "-"),
                ("argmax", "Argmax, always transfer", style.ORANGE, "-"),
                ("trust", "TRUST-Diff", style.AQUA, "--")]


def _probe_pixels(hr, wl):
    """Three homogeneous probes on distinct land covers -- vegetation, a bright
    roof and dark asphalt -- chosen exactly as Fig. 7 of the article does,
    but found automatically on this tile."""
    idx = lambda t: int(np.argmin(np.abs(wl - t)))
    nir, red = hr[idx(830)], hr[idx(660)]
    ndvi = (nir - red) / (nir + red + 1e-6)
    lum = hr.mean(0)
    loc = np.maximum(uniform_filter(lum ** 2, 9) - uniform_filter(lum, 9) ** 2, 0)
    homo = np.sqrt(loc) < np.percentile(np.sqrt(loc), 25)
    H, W = lum.shape
    inner = np.zeros_like(homo); inner[28:H - 28, 28:W - 28] = True
    ok = homo & inner & (hr.max(0) < 0.985)
    out = []
    for score, name in [(ndvi, "vegetation"),
                        (np.where(ndvi < 0.15, lum, -1), "bright roof"),
                        (np.where(ndvi < 0.15, -lum, -1e9), "asphalt")]:
        s_ = np.where(ok, score, -1e9)
        y, x = np.unravel_index(int(np.argmax(s_)), s_.shape)
        out.append((int(y), int(x), name))
        ok = ok & ((np.arange(H)[:, None] - y) ** 2 + (np.arange(W)[None, :] - x) ** 2 > 30 ** 2)
    return out


def spectral_figure(tag, out_name):
    d = load(tag)
    case, res, met = d["case"], d["res"], d["met"]
    hr = case["hr"].astype(np.float64); wl = case["wl"]
    probes = _probe_pixels(hr, wl)

    fig = plt.figure(figsize=(7.16, 2.75))
    gs = GridSpec(1, 4, figure=fig, wspace=0.32, width_ratios=[1, 1, 1, 1.30],
                  left=0.056, right=0.994, top=0.885, bottom=0.235)
    for p, (yy, xx, nm) in enumerate(probes):
        ax = fig.add_subplot(gs[0, p])
        ax.plot(wl, hr[:, yy, xx], color="#101010", lw=1.6, label="Ground truth", zorder=5)
        for k, lab, col, ls in SPEC_METHODS:
            ax.plot(wl, res[k][:, yy, xx], color=col, lw=1.15, ls=ls, label=lab)
        ax.set_title(f"({chr(97+p)}) {nm}, pixel ({yy}, {xx})", fontsize=6.3, pad=3)
        ax.set_xlabel("wavelength (nm)", labelpad=1.5)
        if p == 0:
            ax.set_ylabel("reflectance (scaled)", labelpad=2)
            ax.legend(frameon=False, loc="upper center", fontsize=5.3,
                      handlelength=1.5, borderpad=0.1, labelspacing=0.22,
                      bbox_to_anchor=(0.5, -0.20), ncol=2, columnspacing=1.0)
        ax.tick_params(length=2, pad=1.5)
        ax.margins(x=0.02)

    sam_maps = {k: metrics.sam(res[k], hr, per_pixel=True) for k, _, _, _ in SPEC_METHODS}
    vmax = float(np.percentile(np.stack(list(sam_maps.values())), 99))
    sub = gs[0, 3].subgridspec(1, 3, wspace=0.05)
    for q, (k, lab, _, _) in enumerate(SPEC_METHODS):
        ax = style.bare(fig.add_subplot(sub[0, q]))
        ax.imshow(sam_maps[k], cmap=style.SEQ_ORANGE, vmin=0, vmax=vmax)
        for (yy, xx, _) in probes:
            ax.plot(xx, yy, marker="o", ms=2.6, mfc="none", mec="white", mew=0.9)
        ax.set_title(f"(d) {lab.split(',')[0]}" if q == 0 else lab.split(",")[0],
                     fontsize=5.9, pad=2.5)
        sub_txt = f"SAM {met[k]['SAM']:.2f}$\\degree$"
        if np.isfinite(met[k].get("eLR", np.nan)):
            sub_txt += f"\n$e_{{LR}}$ {met[k]['eLR']:.1e}"
        ax.text(0.5, -0.035, sub_txt, transform=ax.transAxes, ha="center", va="top",
                fontsize=5.3, color=style.INK2, linespacing=1.3)
    bb0 = fig.add_subplot(sub[0, 0]).get_position(); fig.axes[-1].remove()
    bb2 = fig.add_subplot(sub[0, 2]).get_position(); fig.axes[-1].remove()
    cax = fig.add_axes([bb0.x0, 0.115, bb2.x1 - bb0.x0, 0.032])
    cb = fig.colorbar(plt.cm.ScalarMappable(norm=plt.Normalize(0, vmax),
                                            cmap=style.SEQ_ORANGE), cax=cax,
                      orientation="horizontal")
    cb.set_label("per-pixel SAM (degrees)", fontsize=5.5, labelpad=2.0)
    cb.outline.set_linewidth(0.4); cb.outline.set_edgecolor(style.MUTED)
    cb.ax.tick_params(labelsize=5.2, length=1.8, pad=1)
    fig.savefig(f"{FIG}/{out_name}.pdf"); fig.savefig(f"{FIG}/{out_name}.png", dpi=600)
    plt.close(fig)


# ------------------------------------------- Fig. 13: ROC and reliability diagram
def reliability_figure(tags, out_name):
    fig = plt.figure(figsize=(7.16, 2.5))
    gs = GridSpec(1, 3, figure=fig, wspace=0.30, width_ratios=[1, 1, 1],
                  left=0.062, right=0.992, top=0.88, bottom=0.17)

    ax = fig.add_subplot(gs[0, 0])
    for i, tag in enumerate(tags):
        d = load(tag); m = d["res"]["trust_m"]; nc = d["case"]["nc"]
        fpr, tpr, _ = roc_curve((~nc).ravel(), m.ravel())
        au = roc_auc_score((~nc).ravel(), m.ravel())
        ax.plot(fpr, tpr, color=style.CAT[i], lw=1.6,
                label=f"{tag.capitalize()}  AUROC {au:.3f}")
    ax.plot([0, 1], [0, 1], color=style.MUTED, lw=0.8, ls=(0, (3, 3)))
    ax.set_xlabel("false-positive rate"); ax.set_ylabel("true-positive rate")
    ax.set_title("(a) reliability as a detector of correspondence", fontsize=6.6, pad=3)
    ax.legend(frameon=False, loc="lower right", fontsize=5.8, handlelength=1.4)
    ax.set_xlim(0, 1); ax.set_ylim(0, 1); ax.tick_params(length=2, pad=1.5)

    ax = fig.add_subplot(gs[0, 1])
    wbar = 0.045
    for i, tag in enumerate(tags):
        d = load(tag); m = d["res"]["trust_m"]; nc = d["case"]["nc"]
        e, curve = metrics.ece(m, ~nc)
        conf = np.array([c[0] for c in curve]); acc = np.array([c[1] for c in curve])
        ok = ~np.isnan(conf)
        ax.bar(conf[ok] + (i - 0.5) * wbar, acc[ok], width=wbar, color=style.CAT[i],
               edgecolor=style.SURFACE, linewidth=0.6,
               label=f"{tag.capitalize()}  ECE {e:.3f}")
    ax.plot([0, 1], [0, 1], color=style.MUTED, lw=0.8, ls=(0, (3, 3)))
    ax.set_xlabel("predicted reliability $m$"); ax.set_ylabel("observed correspondence")
    ax.set_title("(b) reliability diagram", fontsize=6.6, pad=3)
    ax.legend(frameon=False, loc="upper left", fontsize=5.8, handlelength=1.0)
    ax.set_xlim(0, 1); ax.set_ylim(0, 1); ax.tick_params(length=2, pad=1.5)

    ax = fig.add_subplot(gs[0, 2])
    labs, vals, cols = [], [], []
    for i, tag in enumerate(tags):
        d = load(tag)
        for k, nm in [("argmax", "argmax"), ("softattn", "soft attn."),
                      ("balanced", "balanced"), ("trust", "TRUST")]:
            labs.append(f"{tag[:3].capitalize()} {nm}")
            vals.append(d["met"][k]["RIH"])
            cols.append(style.CAT[i])
    ypos = np.arange(len(labs))
    ax.barh(ypos, vals, color=cols, height=0.62, edgecolor=style.SURFACE, linewidth=0.6)
    for y, v in zip(ypos, vals):
        ax.text(v + 0.002, y, f"{v:.3f}", va="center", fontsize=5.4, color=style.INK2)
    ax.set_yticks(ypos); ax.set_yticklabels(labs, fontsize=5.6)
    ax.invert_yaxis(); ax.set_xlabel("RIH inside $\\Omega_{nc}$  (lower is better)")
    ax.set_title("(c) reference-induced hallucination", fontsize=6.6, pad=3)
    ax.grid(axis="y", visible=False); ax.tick_params(length=2, pad=1.5)
    ax.set_xlim(0, max(vals) * 1.22)

    fig.savefig(f"{FIG}/{out_name}.pdf"); fig.savefig(f"{FIG}/{out_name}.png", dpi=600)
    plt.close(fig)


# --------------------------------------------- Fig. 15: correspondence quality
GOOD, BAD = "#0ca30c", "#d03b3b"          # reserved status colours, always labelled


def correspondence_figure(tag, out_name, n_draw=70, seed=0):
    """Correctness of the correspondences at an EQUAL acceptance rate.

    The three matchers accept very different numbers of regions, so comparing
    their raw error rates would compare different subsets.  Each variant is
    therefore scored on its own N most reliable regions, with N common to all
    three (the smallest accepted set), which is the comparison the ranking in
    Fig. 11 of the article is meant to make.
    """
    import pcm
    from scipy.ndimage import map_coordinates
    d = load(tag)
    case = d["case"]
    hr = case["hr"].astype(np.float64); nc = case["nc"]
    R = case["R_true"].astype(np.float64)
    zy = np.tensordot(R, hr, axes=([1], [0]))
    zy = (zy - zy.min()) / (zy.max() - zy.min())
    ty, tx, th, tw = case["tgt_rect"]; ry, rx, rh, rw = case["ref_rect"]
    dy, dx = case["warp"]
    refg = pcm.ReferenceGraph(case["y"].astype(np.float64), origin=(ry, rx),
                              n_segments=d["cfg"]["n_seg_y"])

    modes = [("argmax", "Argmax over descriptors", dict(mode="argmax")),
             ("uot", "Unbalanced OT, no structure ($\\alpha=0$)", dict(mode="fugw", alpha=0.0)),
             ("fugw", "Full FUGW coupling", dict(mode="fugw", alpha=d["cfg"]["alpha"]))]

    runs = []
    for key, title, kw in modes:
        out = pcm.refresh(zy, refg, (ty, tx), n_segments=d["cfg"]["n_seg_t"],
                          kc=d["cfg"]["kc"], tau=d["cfg"]["tau"],
                          geo_radius=d["cfg"]["geo_radius"], **kw)
        gT, pi, m = out["gT"], out["pi"], out["m"]
        j = np.argmax(pi, 1)
        uy = gT.p[:, 0] + ty - ry; ux = gT.p[:, 1] + tx - rx
        iy = np.clip(uy, 0, rh - 1); ix = np.clip(ux, 0, rw - 1)
        qy = uy - map_coordinates(dy, np.stack([iy, ix]), order=1, mode="nearest")
        qx = ux - map_coordinates(dx, np.stack([iy, ix]), order=1, mode="nearest")
        py = refg.p[j, 0] / refg.rho[j]; px = refg.p[j, 1] / refg.rho[j]
        node_nc = np.array([nc[gT.lab == i].mean() > 0.5 for i in range(gT.n)])
        correct = (np.hypot(py - qy, px - qx) <= 3.0 * gT.s) & (~node_nc)
        runs.append(dict(key=key, title=title, gT=gT, m=m, py=py, px=px,
                         correct=correct, n_acc=int((m > 0.5).sum())))

    N = max(120, min(r["n_acc"] for r in runs))
    rng = np.random.default_rng(seed)
    tgt_rgb = falsecolour(zy, bands=(2, 1, 0))
    ref_rgb = falsecolour(case["y"], bands=(2, 1, 0))

    fig = plt.figure(figsize=(7.16, 3.35))
    gs = GridSpec(1, 3, figure=fig, wspace=0.05, left=0.10, right=0.90,
                  top=0.845, bottom=0.115)
    stats = {}
    for c, r in enumerate(runs):
        sel = np.argsort(-r["m"])[:N]
        wrong = float((~r["correct"][sel]).mean())
        stats[r["key"]] = (wrong, N, r["n_acc"])

        # crop the reference to the span the target can map into, so the two
        # images sit at a comparable width
        c0 = int(max(0, tx - rx - 48)); c1 = int(min(rw, tx - rx + tw + 48))
        rr0 = int(max(0, ty - ry - 48)); rr1 = int(min(rh, ty - ry + th + 48))
        refc = ref_rgb[rr0:rr1, c0:c1]
        maskc = case["nc_ref"][rr0:rr1, c0:c1].astype(float)
        pad = 7
        Hc, Wc = th + pad + refc.shape[0], max(tw, refc.shape[1])
        canvas = np.ones((Hc, Wc, 3))
        canvas[:th, :tw] = tgt_rgb
        canvas[th + pad:th + pad + refc.shape[0], :refc.shape[1]] = refc
        ax = style.bare(fig.add_subplot(gs[0, c]))
        ax.imshow(canvas)
        ax.contour(np.arange(Wc), np.arange(Hc),
                   np.pad(maskc, ((th + pad, Hc - th - pad - refc.shape[0]),
                                  (0, Wc - refc.shape[1]))),
                   levels=[0.5], colors=[style.BLUE], linewidths=0.55)
        draw = rng.choice(sel, size=min(n_draw, len(sel)), replace=False)
        for i in draw:
            ax.plot([r["gT"].p[i, 1], r["px"][i] - c0],
                    [r["gT"].p[i, 0], th + pad + r["py"][i] - rr0],
                    color=GOOD if r["correct"][i] else BAD, lw=0.45, alpha=0.9)
        ax.set_title(f"({chr(97+c)}) {r['title']}", fontsize=6.3, pad=2.6)
        ax.text(0.5, -0.014,
                f"{100*wrong:.1f} % wrong over the {N} most reliable regions\n"
                f"({r['n_acc']} regions accepted at $m > 0.5$)",
                transform=ax.transAxes, ha="center", va="top", fontsize=5.5,
                color=style.INK2, linespacing=1.35)
        if c == 0:
            for yy, lab in [(0.985, "target"), (th / Hc - 0.012, "unpaired reference")]:
                ax.text(0.012, yy, lab, transform=ax.transAxes, fontsize=5.6,
                        va="top", color="white",
                        bbox=dict(fc=style.INK, ec="none", pad=1.0, alpha=0.6))
    h = [plt.Line2D([], [], color=GOOD, lw=1.5), plt.Line2D([], [], color=BAD, lw=1.5),
         plt.Line2D([], [], color=style.BLUE, lw=1.1)]
    fig.legend(h, ["correct match (within $3s_i$ of the true warp and outside $\\Omega_{nc}$)",
                   "incorrect match", "boundary of the replaced content"],
               frameon=False, fontsize=5.8, ncol=3, loc="upper center",
               bbox_to_anchor=(0.5, 1.004), handlelength=1.7, columnspacing=1.5)
    fig.savefig(f"{FIG}/{out_name}.pdf"); fig.savefig(f"{FIG}/{out_name}.png", dpi=600)
    plt.close(fig)
    return stats


# ------------------------------------- CNC-Bench construction panel (Fig. 4 style)
def construction_figure(out_name, zetas=(0.2, 0.4, 0.6, 0.8)):
    import prep, cases as C
    h, hwl = prep.load_houston(); p, pwl = prep.load_pavia()
    base = C.houston_case()
    wl = base["wl"]
    idx = lambda t: int(np.argmin(np.abs(wl - t)))
    fig = plt.figure(figsize=(7.16, 3.5))
    gs = GridSpec(3, 4, figure=fig, wspace=0.16, hspace=0.46,
                  height_ratios=[1.25, 1, 1], left=0.048, right=0.992,
                  top=0.915, bottom=0.085)

    ax = style.bare(fig.add_subplot(gs[0, 0]))
    ax.imshow(falsecolour(base["hr"], bands=(idx(660), idx(560), idx(480))))
    ax.set_title("(a) HR-HSI target, Houston 2013\n$256^2$, CASI, 144 bands", fontsize=6.0, pad=2.5)

    ax = style.bare(fig.add_subplot(gs[0, 1]))
    ax.imshow(falsecolour(base["lr"], bands=(idx(660), idx(560), idx(480))),
              interpolation="nearest")
    ax.set_title("(b) LR-HSI input $X$\nGaussian PSF + $\\times4$ decimation", fontsize=6.0, pad=2.5)

    ax = style.bare(fig.add_subplot(gs[0, 2]))
    ax.imshow(falsecolour(base["y"], bands=(2, 1, 0)))
    ry, rx, rh, rw = base["ref_rect"]; ty, tx, th, tw = base["tgt_rect"]
    ax.add_patch(Rectangle((tx - rx, ty - ry), tw, th, fill=False, ec="white", lw=1.4))
    ax.add_patch(Rectangle((tx - rx, ty - ry), tw, th, fill=False, ec=style.BLUE, lw=0.8))
    ax.set_title("(c) unpaired reference $Y$\nwarp + new radiometry + change", fontsize=6.0, pad=2.5)

    ax = fig.add_subplot(gs[0, 3])
    R = base["R_true"]
    for b in range(R.shape[0]):
        ax.plot(wl, R[b] / R[b].max(), color=style.CAT[b % 3],
                ls=["-", "-", "-", (0, (4, 2))][b], lw=1.3,
                label=f"{base['srf_centres'][b]:.0f} nm")
    ax.set_title("(d) simulated responses $R$", fontsize=6.0, pad=2.5)
    ax.set_xlabel("wavelength (nm)", labelpad=1.5)
    ax.set_ylabel("normalised gain", labelpad=2)
    ax.legend(frameon=False, fontsize=5.2, handlelength=1.2, loc="upper right",
              labelspacing=0.2, borderpad=0.1)
    ax.set_ylim(0, 1.28); ax.tick_params(length=2, pad=1.5)

    for q, z in enumerate(zetas):
        c = prep.build_case("H", h, hwl, C.HOUSTON_TGT, C.HOUSTON_REF,
                            unrelated_cube=p, unrelated_wl=pwl,
                            unrelated_rect=(0, 0, 300, 340), ratio=4, zeta=z,
                            warp_amp=3.0, seed=0)
        ax = style.bare(fig.add_subplot(gs[1, q]))
        ax.imshow(falsecolour(c["y"], bands=(2, 1, 0)))
        ax.set_title(f"$\\zeta$ = {z:.1f}  (measured {c['measured_zeta']:.2f})",
                     fontsize=6.0, pad=2.2)
        if q == 0:
            ax.set_ylabel("(e) CNC-Bench\nreferences", fontsize=6.0, labelpad=2)
        ax = style.bare(fig.add_subplot(gs[2, q]))
        ax.imshow(c["nc"].astype(float), cmap=style.BINARY, vmin=0, vmax=1)
        ax.text(0.5, -0.03, f"$|\\Omega_{{nc}}|$ = {100*c['nc'].mean():.0f} % of tile",
                transform=ax.transAxes, ha="center", va="top", fontsize=5.4,
                color=style.INK2)
        if q == 0:
            ax.set_ylabel("(f) true $\\Omega_{nc}$\nin target coords", fontsize=6.0, labelpad=2)


    fig.text(0.5, 0.012, "In (f) the dark region is where the reference has no valid "
             "counterpart: the replacement blobs plus the part of the target that the "
             "reference window does not cover.",
             ha="center", va="bottom", fontsize=5.6, color=style.INK2)
    fig.savefig(f"{FIG}/{out_name}.pdf"); fig.savefig(f"{FIG}/{out_name}.png", dpi=600)
    plt.close(fig)


# ------------------------------------------------ Fig. 11: CNC-Bench zeta sweep
def zeta_figure(out_name="fig08_cnc_sweep"):
    d = pickle.load(open(f"{OUT}/zeta_sweep.pkl", "rb"))
    rows, psnr0 = d["rows"], d["psnr0"]
    series = [("argmax", "Argmax, always transfer", style.BLUE, "o"),
              ("softattn", "Soft attention, always transfer", style.ORANGE, "s"),
              ("trust", "TRUST-Diff", style.AQUA, "^")]
    get = lambda m, k: ([r["zeta"] for r in rows if r["method"] == m],
                        [r[k] for r in rows if r["method"] == m])

    fig = plt.figure(figsize=(7.16, 2.35))
    gs = GridSpec(1, 3, figure=fig, wspace=0.28, left=0.062, right=0.993,
                  top=0.86, bottom=0.30)

    ax = fig.add_subplot(gs[0, 0])
    ax.axhline(psnr0, color=style.MUTED, lw=1.0, ls=(0, (3, 3)))
    ax.text(0.02, psnr0, " no-reference baseline (A0)", va="bottom", ha="left",
            fontsize=5.4, color=style.INK2)
    for k, lab, col, mk in series:
        zs, vs = get(k, "PSNR")
        ax.plot(zs, vs, color=col, marker=mk, ms=3.4, label=lab)
    ax.set_xlabel("non-correspondence fraction $\\zeta$"); ax.set_ylabel("PSNR (dB)")
    ax.set_title("(a) reconstruction", fontsize=6.6, pad=3)
    ax.tick_params(length=2, pad=1.5)

    ax = fig.add_subplot(gs[0, 1])
    for k, lab, col, mk in series:
        zs, vs = get(k, "RIH")
        ax.plot(zs, vs, color=col, marker=mk, ms=3.4, label=lab)
    ax.set_xlabel("non-correspondence fraction $\\zeta$")
    ax.set_ylabel("RIH inside $\\Omega_{nc}$")
    ax.set_title("(b) hallucination", fontsize=6.6, pad=3)
    ax.tick_params(length=2, pad=1.5)

    ax = fig.add_subplot(gs[0, 2])
    allrg = [v for k, _, _, _ in series for v in get(k, "RG")[1]]
    lo, hi = min(allrg) - 0.06, 0.10
    ax.set_ylim(lo, hi)
    ax.axhspan(-0.1, hi, color="#f1f0ec", zorder=0)      # H1 would hold in here
    ax.axhline(-0.1, color=style.MUTED, lw=0.9, ls=(0, (3, 3)))
    ax.text(0.02, -0.1, " H1 holds above this line", va="bottom", ha="left",
            fontsize=5.4, color=style.INK2, transform=ax.get_yaxis_transform())
    for k, lab, col, mk in series:
        zs, vs = get(k, "RG")
        ax.plot(zs, vs, color=col, marker=mk, ms=3.4, label=lab)
    ax.axhline(0.0, color=style.INK2, lw=0.7)
    ax.set_xlabel("non-correspondence fraction $\\zeta$")
    ax.set_ylabel("reference gain (dB)")
    ax.set_title("(c) reference gain vs. A0", fontsize=6.6, pad=3)
    ax.tick_params(length=2, pad=1.5)

    h, l = ax.get_legend_handles_labels()
    fig.legend(h, l, frameon=False, fontsize=6.0, ncol=3, loc="lower center",
               bbox_to_anchor=(0.53, -0.012), handlelength=1.8, columnspacing=2.0)
    fig.savefig(f"{FIG}/{out_name}.pdf"); fig.savefig(f"{FIG}/{out_name}.png", dpi=600)
    plt.close(fig)
    return {m: dict(zip(*get(m, "RG"))) for m, _, _, _ in series}


# ------------------------------- Fig. 14: ablation dot plot, drawn from Table XIII
TABLE_XIII = {          # transcribed from Table 11 of the article
    "Houston": [("TRUST-Diff (full)", 45.88, 1.31, 0.022, 0.936),
                ("TPC $\\rightarrow$ InfoNCE", 45.26, 1.49, 0.035, 0.874),
                ("TPC $\\rightarrow$ triplet", 44.93, 1.59, 0.042, 0.842),
                ("without $\\mathcal{L}_{rel}$", 45.42, 1.44, 0.040, 0.853),
                ("exact $\\rightarrow$ soft data term", 45.24, 1.45, 0.050, 0.924),
                ("structure tensor $\\rightarrow$ L2", 45.08, 1.56, 0.039, 0.915),
                ("estimated $\\rightarrow$ nominal SRF", 45.53, 1.47, 0.031, 0.929)],
    "Pavia":   [("TRUST-Diff (full)", 38.05, 3.72, 0.034, 0.902),
                ("TPC $\\rightarrow$ InfoNCE", 37.44, 3.94, 0.048, 0.841),
                ("TPC $\\rightarrow$ triplet", 37.09, 4.07, 0.055, 0.808),
                ("without $\\mathcal{L}_{rel}$", 37.62, 3.88, 0.053, 0.819),
                ("exact $\\rightarrow$ soft data term", 37.38, 3.99, 0.062, 0.889),
                ("structure tensor $\\rightarrow$ L2", 37.22, 4.12, 0.051, 0.881),
                ("estimated $\\rightarrow$ nominal SRF", 37.71, 3.91, 0.043, 0.895)],
}


def ablation_figure(out_name="fig10_ablation"):
    names = [r[0] for r in TABLE_XIII["Houston"]]
    y = np.arange(len(names))
    panels = [("(a) $\\Delta$PSNR vs full (dB)", 1, True),
              ("(b) $\\Delta$SAM vs full", 2, True),
              ("(c) RIH", 3, False),
              ("(d) AUROC of $m$", 4, False)]
    fig = plt.figure(figsize=(7.16, 2.3))
    gs = GridSpec(1, 4, figure=fig, wspace=0.14, left=0.225, right=0.992,
                  top=0.86, bottom=0.235)
    for pi, (title, col, signed) in enumerate(panels):
        ax = fig.add_subplot(gs[0, pi])
        ax.axhspan(-0.5, 0.5, color="#f3f2ee", zorder=0)
        for si, (ds, colr, mk) in enumerate([("Houston", style.BLUE, "o"),
                                             ("Pavia", style.ORANGE, "s")]):
            vals = np.array([r[col] for r in TABLE_XIII[ds]], float)
            if signed:
                vals = vals - vals[0]
            ax.plot(vals, y + (si - 0.5) * 0.22, ls="none", marker=mk, ms=4.0,
                    color=colr, label=ds)
        if signed:
            ax.axvline(0.0, color=style.INK2, lw=0.8)
        ax.set_yticks(y)
        ax.set_yticklabels(names if pi == 0 else [], fontsize=5.8)
        ax.invert_yaxis()
        ax.set_title(title, fontsize=6.4, pad=3)
        ax.grid(axis="y", visible=False)
        ax.tick_params(length=2, pad=1.5, labelsize=5.8)
    h, l = fig.axes[0].get_legend_handles_labels()
    fig.legend(h, l, frameon=False, fontsize=6.2, ncol=2, loc="lower center",
               bbox_to_anchor=(0.6, -0.015), handlelength=1.2, columnspacing=2.0)
    fig.savefig(f"{FIG}/{out_name}.pdf"); fig.savefig(f"{FIG}/{out_name}.png", dpi=600)
    plt.close(fig)


# ------------------------------------------- Fig. 17: parameter sensitivity
def param_figure(out_name="fig13_parameters"):
    d = pickle.load(open(f"{OUT}/param_sweep.pkl", "rb"))
    cols = [("k", "subspace dimension $k$"), ("T", "reverse steps $T$"),
            ("eps", "entropic reg. $\\varepsilon$"), ("tau", "mass abstention $\\tau$")]
    fig = plt.figure(figsize=(7.16, 2.75))
    gs = GridSpec(2, 4, figure=fig, wspace=0.34, hspace=0.30,
                  left=0.088, right=0.993, top=0.90, bottom=0.235)
    for ci, (key, lab) in enumerate(cols):
        for ri, metric in enumerate(["PSNR", "RIH"]):
            ax = fig.add_subplot(gs[ri, ci])
            for si, (tag, colr, mk) in enumerate([("houston", style.BLUE, "o"),
                                                  ("pavia", style.ORANGE, "s")]):
                pts = d[tag]["res"][key]
                xs = [p[0] for p in pts]; ys = [p[1][metric] for p in pts]
                ax.plot(xs, ys, color=colr, marker=mk, ms=3.2,
                        label=tag.capitalize() if (ri == 0 and ci == 0) else None)
            ax.axvline(d["houston"]["default"][key], color=style.MUTED, lw=0.8,
                       ls=(0, (2, 2)))
            if metric == "RIH":
                ax.set_yscale("log")
                ax.set_xlabel(lab, labelpad=1.5)
            else:
                ax.set_title(f"({chr(97+ci)}) {lab}", fontsize=6.3, pad=3)
            if ci == 0:
                ax.set_ylabel("PSNR (dB)" if metric == "PSNR" else "RIH", labelpad=2)
            ax.tick_params(length=2, pad=1.5, labelsize=5.8)
    h, l = fig.axes[0].get_legend_handles_labels()
    fig.legend(h, l, frameon=False, fontsize=6.2, ncol=2, loc="lower center",
               bbox_to_anchor=(0.53, -0.012), handlelength=1.3, columnspacing=2.0)
    fig.savefig(f"{FIG}/{out_name}.pdf"); fig.savefig(f"{FIG}/{out_name}.png", dpi=600)
    plt.close(fig)
    return {t: d[t]["res"]["tau"] for t in ("houston", "pavia")}


# --------------------------------------------- Fig. 18: cost vs reference size
def runtime_figure(out_name="fig14_runtime"):
    """What this figure can honestly establish is the SCALING of each cost with
    reference size, not a speed-up over a competitor that cannot be run here.
    The per-refresh matching cost is flat in N_Y because only the candidate query
    depends on the reference; the index build is linear and paid once per scene.
    """
    d = pickle.load(open(f"{OUT}/runtime.pkl", "rb"))
    rows = d["rows"]
    side = np.array([r["side"] for r in rows], float)
    ann = np.array([r["t_match_ann"] for r in rows])
    exh = np.array([r["t_match_exhaustive"] for r in rows])
    idx = np.array([r["t_index"] for r in rows])
    ny = np.array([r["n_pixels"] for r in rows], float)
    nodes = np.array([r["n_ref_nodes"] for r in rows], float)

    fig = plt.figure(figsize=(7.16, 2.35))
    gs = GridSpec(1, 2, figure=fig, wspace=0.27, left=0.078, right=0.993,
                  top=0.87, bottom=0.31)

    ax = fig.add_subplot(gs[0, 0])
    ax.plot(side, ann, color=style.BLUE, marker="o", ms=3.6,
            label="candidate-set query (TRUST-Diff)")
    ax.plot(side, exh, color=style.ORANGE, marker="s", ms=3.6,
            label="score every reference node")
    ax.set_ylim(0, max(ann.max(), exh.max()) * 1.35)
    ax.set_xlabel("reference side length (px)")
    ax.set_ylabel("matching time per refresh (s)")
    ax.set_title("(a) one correspondence refresh", fontsize=6.6, pad=3)
    ax.tick_params(length=2, pad=1.5)

    ax = fig.add_subplot(gs[0, 1])
    ax.plot(ny / 1e3, idx, color=style.BLUE, marker="o", ms=3.6,
            label="reference graph, descriptors and index")
    z = np.polyfit(ny, idx, 1)
    ax.plot(ny / 1e3, np.polyval(z, ny), color=style.MUTED, lw=0.9, ls=(0, (3, 3)),
            label="linear fit in $N_Y$")
    ax.set_xlabel("reference size $N_Y$ (thousand pixels)")
    ax.set_ylabel("one-off build time (s)")
    ax.set_title("(b) per-scene index build", fontsize=6.6, pad=3)
    ax.legend(frameon=False, fontsize=5.6, loc="upper left", handlelength=1.5)
    ax.tick_params(length=2, pad=1.5)

    h, l = fig.axes[0].get_legend_handles_labels()
    fig.legend(h, l, frameon=False, fontsize=6.0, ncol=2, loc="lower center",
               bbox_to_anchor=(0.30, -0.012), handlelength=1.5, columnspacing=1.8)
    fig.savefig(f"{FIG}/{out_name}.pdf"); fig.savefig(f"{FIG}/{out_name}.png", dpi=600)
    plt.close(fig)
    return dict(ann_range=(float(ann.min()), float(ann.max())),
                ann_trend=float(np.polyfit(ny, ann, 1)[0] * 1e5),
                idx_range=(float(idx.min()), float(idx.max())),
                nodes=(int(nodes.min()), int(nodes.max())),
                ny=(int(ny.min()), int(ny.max())))


# ------------------------------ Fig. 19: downstream classification, Indian Pines
IP_CLASSES = ["Alfalfa", "Corn-notill", "Corn-mintill", "Corn", "Grass-pasture",
              "Grass-trees", "Grass-pasture-mowed", "Hay-windrowed", "Oats",
              "Soybean-notill", "Soybean-mintill", "Soybean-clean", "Wheat",
              "Woods", "Buildings-Grass-Trees", "Stone-Steel-Towers"]
IP_COLORS = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#008300",
             "#4a3aa7", "#e34948", "#7fd3f5", "#b06a2c", "#6fbf4a", "#c48fd0",
             "#00786e", "#8a8985", "#f2c46b", "#1f3d7a"]


def classify_figure(out_name="fig15_classification"):
    from matplotlib.colors import ListedColormap
    from matplotlib.patches import Patch
    d = pickle.load(open(f"{OUT}/indian_classify.pkl", "rb"))
    case, maps, table, cm = d["case"], d["maps"], d["table"], d["cm"]
    gt = case["gt_labels"]
    cmap = ListedColormap(["#ffffff"] + IP_COLORS)

    order = ["Bicubic", "No-reference (A0)", "Argmax, always transfer", "TRUST-Diff"]
    fig = plt.figure(figsize=(7.16, 2.15))
    gs = GridSpec(2, 6, figure=fig, wspace=0.06, hspace=0.30,
                  height_ratios=[1, 0.16], left=0.006, right=0.995,
                  top=0.865, bottom=0.03)

    ax = style.bare(fig.add_subplot(gs[0, 0]))
    ax.imshow(gt, cmap=cmap, vmin=0, vmax=16, interpolation="nearest")
    ax.set_title("Ground-truth labels", fontsize=6.2, pad=2.5)
    for c, name in enumerate(order):
        ax = style.bare(fig.add_subplot(gs[0, c + 1]))
        ax.imshow(maps[name], cmap=cmap, vmin=0, vmax=16, interpolation="nearest")
        ax.set_title(name.replace(", always transfer", ",\nalways transfer"),
                     fontsize=6.2, pad=2.5, linespacing=1.0)
        t = table[name]
        ax.text(0.5, -0.02, f"OA {t['OA']:.1f} %  $\\kappa$ {t['kappa']:.3f}",
                transform=ax.transAxes, ha="center", va="top", fontsize=5.4,
                color=style.INK2)

    ax = fig.add_subplot(gs[0, 5])
    im = ax.imshow(cm, cmap=style.SEQ_BLUE, vmin=0, vmax=1)
    ax.set_title("TRUST-Diff, normalised\nconfusion matrix", fontsize=6.2, pad=2.5,
                 linespacing=1.0)
    ax.set_xticks([]); ax.set_yticks([]); ax.grid(False)
    for sp in ax.spines.values():
        sp.set_color("#d8d7d2"); sp.set_linewidth(0.5)
    cax = ax.inset_axes([0.0, -0.09, 1.0, 0.045])
    cb = fig.colorbar(im, cax=cax, orientation="horizontal")
    cb.set_ticks([0, 1]); cb.set_ticklabels(["0", "1"])
    cb.outline.set_linewidth(0.4); cb.outline.set_edgecolor(style.MUTED)
    cb.ax.tick_params(labelsize=5.0, length=1.6, pad=0.8)

    axl = fig.add_subplot(gs[1, :]); axl.set_axis_off()
    handles = [Patch(facecolor=IP_COLORS[i], edgecolor="none", label=IP_CLASSES[i])
               for i in range(16)]
    axl.legend(handles=handles, frameon=False, fontsize=5.0, ncol=8,
               loc="upper center", handlelength=0.9, handleheight=0.9,
               columnspacing=1.0, labelspacing=0.3, borderpad=0.0)
    fig.savefig(f"{FIG}/{out_name}.pdf"); fig.savefig(f"{FIG}/{out_name}.png", dpi=600)
    plt.close(fig)
    return table


# Figure names follow the numbering used in the article.
FIGURES = {
    "fig04": ("Fig. 4  CNC-Bench construction",
              lambda: construction_figure("fig04_cnc_construction")),
    "fig05": ("Fig. 5  Houston visual comparison",
              lambda: qualitative_figure("houston", "fig05_houston_qualitative")),
    "fig06": ("Fig. 6  Pavia visual comparison",
              lambda: qualitative_figure("pavia", "fig06_pavia_qualitative")),
    "fig07": ("Fig. 7  spectral fidelity",
              lambda: spectral_figure("houston", "fig07_spectral_fidelity")),
    "fig08": ("Fig. 8  CNC-Bench sweep",
              lambda: zeta_figure("fig08_cnc_sweep")),
    "fig09": ("Fig. 9  reliability as a detector",
              lambda: reliability_figure(["houston", "pavia"], "fig09_reliability")),
    "fig10": ("Fig. 10 ablation",
              lambda: ablation_figure("fig10_ablation")),
    "fig11": ("Fig. 11 correspondences",
              lambda: correspondence_figure("houston", "fig11_correspondence")),
    "fig13": ("Fig. 13 parameter sensitivity",
              lambda: param_figure("fig13_parameters")),
    "fig14": ("Fig. 14 cost against reference size",
              lambda: runtime_figure("fig14_runtime")),
    "fig15": ("Fig. 15 downstream classification",
              lambda: classify_figure("fig15_classification")),
}


def main(what=None):
    from .paths import ensure
    ensure()
    """what: None or ['all'] for everything, else a list of keys of FIGURES."""
    keys = list(FIGURES) if not what or "all" in what else list(what)
    for k in keys:
        if k not in FIGURES:
            raise SystemExit(f"unknown figure {k!r}; choose from "
                             f"{', '.join(FIGURES)} or 'all'")
        label, fn = FIGURES[k]
        out = fn()
        print(f"{label}: done" + (f"  {out}" if out is not None else ""))


if __name__ == "__main__":
    import sys
    main(sys.argv[1:] or ["all"])
