"""PCM-Refresh (Algorithm 2): build the graphs, solve the coupling, read off the
reliability map, and transport the structure tensors into target coordinates."""
import numpy as np
import scipy.sparse as sp
from scipy.ndimage import gaussian_filter, map_coordinates, zoom
from scipy.signal import fftconvolve
from sklearn.neighbors import NearestNeighbors

from . import matching as M


# ----------------------------------------------------------- reference pyramid
class ReferenceGraph:
    """Pyramid of region graphs over the unpaired reference; built once."""

    def __init__(self, y, rhos=(2 ** -0.25, 1.0, 2 ** 0.25), n_segments=2600,
                 origin=(0, 0), seg_scale=True, radii=(2.0, 4.0)):
        self.levels = []
        for rho in rhos:
            img = np.stack([zoom(b, rho, order=1) for b in y]) if abs(rho - 1) > 1e-6 else y
            ns = int(n_segments * (rho ** 2)) if seg_scale else n_segments
            g = M.RegionGraph(img, n_segments=max(ns, 200), rho=rho)
            self.levels.append(g)
        self.origin = np.asarray(origin, float)

        self.p = np.vstack([g.p for g in self.levels])
        self.s = np.concatenate([g.s for g in self.levels])
        self.theta = np.concatenate([g.theta for g in self.levels])
        self.rho = np.concatenate([np.full(g.n, g.rho) for g in self.levels])
        self.level = np.concatenate([np.full(g.n, i) for i, g in enumerate(self.levels)])
        area = np.concatenate([g.a_area / (g.rho ** 2) for g in self.levels])
        self.b = area / area.sum()
        self.n = len(self.s)

        # scene coordinates of every node (for the coarse geolocation prior)
        self.p_scene = self.p / self.rho[:, None] + self.origin[None, :]

        # block-diagonal sparse distance matrices over the whole pyramid
        Ds, D2s, Ws, off = [], [], [], 0
        for g in self.levels:
            D, D2, W = g.distance_matrices()
            Ds.append(D); D2s.append(D2); Ws.append(W)
        self.D = sp.block_diag(Ds).tocsr()
        self.D2 = sp.block_diag(D2s).tocsr()
        self.W = sp.block_diag(Ws).tocsr()

        self.radii = radii
        self.desc_raw = np.vstack([M.canonical_descriptors_multi(g, radii=radii) for g in self.levels])

        # contrast-invariant structure tensors psi psi^T per band, per level
        self.T = []
        for g in self.levels:
            B = g.img.shape[0]
            comp = []
            for b in range(B):
                vy, vx = M.normalized_gradient(g.img[b])
                comp += [vy * vy, vy * vx, vx * vx]
            self.T.append(np.stack(comp))      # (3B, H_l, W_l)


# ----------------------------------------------------------------- one refresh
def refresh(zy, refg: ReferenceGraph, tgt_origin, *, n_segments=1100,
            mode="fugw", kc=32, alpha=0.5, eps=0.10, tau=0.15,
            geo_radius=None, soft_T=0.05, topk_transport=3):
    """zy : (B,H,W) current estimate mapped to the reference bands.

    mode:
      'fugw'    - unbalanced coupling with a dustbin      -> reliability m
      'balanced'- same solver with tau -> large           -> m == 1
      'argmax'  - nearest-descriptor match, always transfer
      'softattn'- softmax attention over candidates, always transfer
    """
    gT = M.RegionGraph(zy, n_segments=n_segments)
    dT_raw = M.canonical_descriptors_multi(gT, radii=refg.radii)
    Ht = M.rank_equalise(dT_raw)
    Hy = M.rank_equalise(refg.desc_raw)
    Ht, Hy = M.reduce_dims(Ht, Hy, d=48)

    p_scene_T = gT.p + np.asarray(tgt_origin, float)[None, :]

    # ---- candidate sets (ANN over descriptors, optional geolocation prior)
    nn = NearestNeighbors(n_neighbors=min(kc, refg.n)).fit(Hy)
    _, idx = nn.kneighbors(Ht)
    mask = np.zeros((gT.n, refg.n), bool)
    rows = np.repeat(np.arange(gT.n), idx.shape[1])
    mask[rows, idx.ravel()] = True
    if geo_radius is not None:
        d2 = ((p_scene_T[:, None, :] - refg.p_scene[None, :, :]) ** 2).sum(-1)
        geo = d2 <= geo_radius ** 2
        keep = mask & geo
        # if the prior empties a row, fall back to the nearest few by geometry
        empty = ~keep.any(1)
        if empty.any():
            near = np.argsort(d2[empty], axis=1)[:, :8]
            for r, cols in zip(np.nonzero(empty)[0], near):
                keep[r, cols] = True
        mask = keep

    C = np.where(mask, M.normalise_cost(1.0 - Ht @ Hy.T, mask), 0.0)

    DT, D2T, WT = gT.distance_matrices()
    a = gT.a

    if mode in ("fugw", "balanced"):
        tt = tau if mode == "fugw" else 1e4
        G = M.fugw(C, a, refg.b, mask, DT, D2T, WT, refg.D, refg.D2, refg.W,
                   alpha=alpha, eps=eps, tau=tt)
        m, pi, r = M.reliability(G, a)
        if mode == "balanced":
            # In the balanced problem the row marginal is constrained to a, so
            # r_i = a_i and m == 1 by definition: every region must be matched
            # and there is no dustbin.  A finite tau only approaches that limit,
            # so the identity is imposed rather than read off a scaling that has
            # not fully converged.
            m = np.ones_like(m)
    elif mode == "argmax":
        j = np.where(mask, Ht @ Hy.T, -np.inf).argmax(1)
        G = np.zeros((gT.n, refg.n)); G[np.arange(gT.n), j] = a
        m = np.ones(gT.n); pi = np.zeros_like(G); pi[np.arange(gT.n), j] = 1.0
    elif mode == "softattn":
        S = np.where(mask, Ht @ Hy.T, -np.inf)
        S = S - S.max(1, keepdims=True)
        P = np.exp(S / soft_T); P /= P.sum(1, keepdims=True) + 1e-30
        G = a[:, None] * P
        m = np.ones(gT.n); pi = P
    else:
        raise ValueError(mode)

    return dict(gT=gT, m=m, pi=pi, G=G, mask=mask, C=C,
                topk=topk_transport, Ht=Ht, Hy=Hy)


# -------------------------------------------------- pixel reliability map
def pixel_reliability(gT, m, smooth=2.0):
    mp = m[gT.lab]
    return gaussian_filter(mp, smooth)


# ------------------------------------------- transported structure tensors (11)
def _rotate_tensors(vals, c, s, nB):
    """Q(dtheta)^T T Q(dtheta) for every 2x2 symmetric tensor stored as
    (t_yy, t_yx, t_xx) triples along axis 0."""
    out = np.empty_like(vals)
    for b in range(nB):
        t11, t12, t22 = vals[3 * b], vals[3 * b + 1], vals[3 * b + 2]
        out[3 * b] = c * c * t11 + 2 * c * s * t12 + s * s * t22
        out[3 * b + 1] = c * s * (t22 - t11) + (c * c - s * s) * t12
        out[3 * b + 2] = s * s * t11 - 2 * c * s * t12 + c * c * t22
    return out


def _refine_shift(A, Tl, pi_c, pj_c, si, c, s, nB, shape, R):
    """Best integer shift of the transported patch, by FFT cross-correlation of
    the target tensor field A against the reference tensor field Tl over a
    window of radius 2 s_i.  Returns the shift in reference-grid pixels."""
    H, W = shape
    Hl, Wl = Tl.shape[1:]
    r = int(np.clip(round(2.0 * si), 7, 22))
    y0 = int(np.clip(round(pi_c[0]) - r, 0, H - 1)); y1 = int(np.clip(round(pi_c[0]) + r + 1, 1, H))
    x0 = int(np.clip(round(pi_c[1]) - r, 0, W - 1)); x1 = int(np.clip(round(pi_c[1]) + r + 1, 1, W))
    a = A[:, y0:y1, x0:x1]
    hh, ww = a.shape[1], a.shape[2]
    if hh < 5 or ww < 5:
        return np.zeros(2)
    # reference window of the same size plus the search margin
    cy = int(round(pj_c[0])); cx = int(round(pj_c[1]))
    ay0 = cy - (int(round(pi_c[0])) - y0) - R
    ax0 = cx - (int(round(pi_c[1])) - x0) - R
    by0, bx0 = max(ay0, 0), max(ax0, 0)
    by1, bx1 = min(ay0 + hh + 2 * R, Hl), min(ax0 + ww + 2 * R, Wl)
    if by1 - by0 < hh + 1 or bx1 - bx0 < ww + 1:
        return np.zeros(2)
    b = _rotate_tensors(Tl[:, by0:by1, bx0:bx1], c, s, nB)
    num = np.zeros((by1 - by0 - hh + 1, bx1 - bx0 - ww + 1))
    for ch in range(3 * nB):
        num += fftconvolve(b[ch], a[ch][::-1, ::-1], mode="valid")
    # normalise by the reference edge energy under the window, otherwise the
    # peak drifts to whichever part of the reference is simply busiest
    tr = sum(b[3 * q] + b[3 * q + 2] for q in range(nB))
    wt = sum(a[3 * q] + a[3 * q + 2] for q in range(nB))
    den = fftconvolve(tr, wt[::-1, ::-1], mode="valid")
    sc = num / np.sqrt(np.maximum(den, 1e-8))
    k = np.unravel_index(int(np.argmax(sc)), sc.shape)
    return np.array([by0 + k[0] - ay0 - R, bx0 + k[1] - ax0 - R], float)


def transport_tensors(gT, pi, m, refg: ReferenceGraph, shape, topk=3, smooth=0.0,
                      m_floor=0.02, zy=None, refine=10):
    """S_b(p) = sum_i w_i(p) sum_j pi_{j|i} Q_ij^T T^Y_b(T_ij(p)) Q_ij.

    `refine` adds a sub-region localisation step: the similarity transform of
    (11) places the transported patch using the two superpixel centroids, but
    SLIC centroids computed on two different images are not exact counterparts,
    and the diagnostic in the text shows that a three-pixel offset already
    destroys the structural information the reference carries.  For each
    accepted match the integer shift in [-refine, refine]^2 that maximises the
    contrast-invariant alignment psi^T S psi against the current estimate `zy`
    is therefore applied.  It refines only the geometry of an already-decided
    correspondence: neither the coupling nor the reliability map is touched.
    """
    H, W = shape
    nB = refg.T[0].shape[0] // 3
    S = np.zeros((3 * nB, H, W))
    Wsum = np.zeros((H, W))

    order = np.argsort(-pi, axis=1)[:, :topk]

    psi = None
    if zy is not None and refine:
        # target-side tensor field, weighted by edge strength.  The refinement
        # score sum_p w(p) psi^T S(p+D) psi is a sum of 12 cross-correlations,
        # so every candidate shift is evaluated at once by FFT.
        A = []
        for b in range(nB):
            vy, vx = M.normalized_gradient(zy[b])
            w = vy ** 2 + vx ** 2
            A += [w * vy * vy, 2.0 * w * vy * vx, w * vx * vx]
        psi = np.stack(A)

    for i in range(gT.n):
        if m[i] < m_floor:
            continue
        sel = gT.lab == i
        if not sel.any():
            continue
        ys, xs = np.nonzero(sel)
        acc = np.zeros((3 * nB, ys.size))
        wtot = 0.0
        for j in order[i]:
            w = pi[i, j]
            if w <= 1e-4:
                continue
            lv = refg.level[j]
            # theta is defined modulo pi, so the raw difference carries a pi
            # ambiguity that would flip the sampled patch by 180 degrees about
            # the centroid.  Wrap it into (-pi/2, pi/2]: the smaller of the two
            # rotations is the right branch unless the scenes are deliberately
            # rotated by more than a right angle.
            dth = np.mod(refg.theta[j] - gT.theta[i] + np.pi / 2, np.pi) - np.pi / 2
            if __import__("os").environ.get("TD_NOROT"):
                dth = 0.0
            c, s = np.cos(dth), np.sin(dth)
            # The scale comes from the pyramid level that won the match, not
            # from the ratio of superpixel areas: SLIC areas fluctuate between
            # the two images even at identical ground sampling distance, and
            # using them stretches the transported patch by tens of percent.
            sc = refg.rho[j]
            dy = ys - gT.p[i, 0]; dx = xs - gT.p[i, 1]
            qy = refg.p[j, 0] + sc * (c * dy - s * dx)
            qx = refg.p[j, 1] + sc * (s * dy + c * dx)
            Tl = refg.T[lv]
            nt = 3 * nB
            Hl, Wl = Tl.shape[1:]

            if psi is not None:
                d = _refine_shift(psi, Tl, gT.p[i], refg.p[j], gT.s[i], c, s, nB,
                                  shape, refine)
                qy = qy + d[0]; qx = qx + d[1]

            ch = np.repeat(np.arange(nt, dtype=np.float64), qy.size)
            co = np.stack([ch, np.tile(qy, nt), np.tile(qx, nt)])
            vals = map_coordinates(Tl, co, order=1, mode="nearest").reshape(nt, qy.size)
            acc += w * _rotate_tensors(vals, c, s, nB)
            wtot += w
        if wtot > 0:
            S[:, ys, xs] += acc / wtot
            Wsum[ys, xs] += 1.0

    good = Wsum > 0
    S[:, good] /= Wsum[good]
    if smooth > 0:
        for t in range(S.shape[0]):
            S[t] = gaussian_filter(S[t], smooth)
    return S, good
