"""
Partial-correspondence matching (Sects. 3.4 and 3.5, Algorithm 2).

Region graphs by SLIC, rotation-canonicalised contrast-invariant descriptors,
similarity-invariant edge features, and a fused unbalanced Gromov-Wasserstein
coupling solved by generalized Sinkhorn scaling (8).  The learned GNN encoder
of Sect. 3.4 is replaced here by the same hand-crafted contrast-invariant
descriptors used for Figs. 1 and 2, so the maps below
illustrate the *mechanism*; they are not trained results.
"""
import numpy as np
import scipy.sparse as sp
from scipy.ndimage import gaussian_filter, map_coordinates
from skimage.segmentation import slic
from skimage.measure import regionprops
from sklearn.neighbors import NearestNeighbors

ETA = 1e-3


# --------------------------------------------------------------- basic fields
def normalized_gradient(I, eta=ETA):
    """psi = grad I / sqrt(|grad I|^2 + eta^2)  (Sect. 3.7)."""
    gy = np.zeros_like(I); gx = np.zeros_like(I)
    gy[1:-1] = 0.5 * (I[2:] - I[:-2]); gy[0] = I[1] - I[0]; gy[-1] = I[-1] - I[-2]
    gx[:, 1:-1] = 0.5 * (I[:, 2:] - I[:, :-2]); gx[:, 0] = I[:, 1] - I[:, 0]; gx[:, -1] = I[:, -1] - I[:, -2]
    g = np.sqrt(gy ** 2 + gx ** 2 + eta ** 2)
    return gy / g, gx / g


def grad_adjoint(vy, vx):
    """Exact adjoint of the centred-difference gradient used above, including
    its one-sided boundary rows.  Verified against a finite-difference check of
    L_ref; an earlier extra negation here made the guidance ascend the energy."""
    out = np.zeros_like(vy)
    out[2:] += 0.5 * vy[1:-1]; out[:-2] -= 0.5 * vy[1:-1]
    out[1] += vy[0]; out[0] -= vy[0]
    out[-1] += vy[-1]; out[-2] -= vy[-1]
    out[:, 2:] += 0.5 * vx[:, 1:-1]; out[:, :-2] -= 0.5 * vx[:, 1:-1]
    out[:, 1] += vx[:, 0]; out[:, 0] -= vx[:, 0]
    out[:, -1] += vx[:, -1]; out[:, -2] -= vx[:, -1]
    return out


def structure_tensor_orientation(I, sigma=2.0):
    """Dominant orientation (mod pi) of the smoothed structure tensor, measured
    in the (row, col) frame from +y towards +x, i.e. the same convention as the
    rotation Q(theta) = [[cos, -sin], [sin, cos]] acting on (dy, dx) that the
    canonical patch sampler and the tensor transport both use."""
    gy, gx = np.gradient(I)
    Jyy = gaussian_filter(gy * gy, sigma)
    Jxx = gaussian_filter(gx * gx, sigma)
    Jyx = gaussian_filter(gy * gx, sigma)
    return 0.5 * np.arctan2(2 * Jyx, Jyy - Jxx)   # in (-pi/2, pi/2]


# ----------------------------------------------------------------- region graph
class RegionGraph:
    """SLIC region graph with nodes (p, s, theta, a) and adjacency edges."""

    def __init__(self, img, n_segments, rho=1.0, compactness=8.0, sigma_or=2.0):
        self.img = img                                  # (B,H,W), float
        self.rho = float(rho)
        B, H, W = img.shape
        rgb = np.moveaxis(img[:3] if B >= 3 else np.repeat(img[:1], 3, 0), 0, -1)
        lab = slic(rgb, n_segments=n_segments, compactness=compactness,
                   channel_axis=-1, start_label=0, enforce_connectivity=True)
        self.lab = lab
        self.n = int(lab.max()) + 1

        lum = img.mean(0)
        orient = structure_tensor_orientation(lum, sigma_or)
        # complex averaging of the doubled angle gives the mod-pi mean
        z = np.exp(2j * orient)

        props = regionprops(lab + 1)
        p = np.zeros((self.n, 2)); s = np.zeros(self.n); a = np.zeros(self.n); th = np.zeros(self.n)
        for r in props:
            i = r.label - 1
            p[i] = r.centroid
            a[i] = r.area
            s[i] = np.sqrt(r.area)
        flat = lab.ravel()
        zs = np.bincount(flat, weights=z.real.ravel(), minlength=self.n) + \
            1j * np.bincount(flat, weights=z.imag.ravel(), minlength=self.n)
        th = 0.5 * np.angle(zs)
        self.p, self.s, self.a_area, self.theta = p, s, a, th
        self.a = a / a.sum()

        # adjacency from label boundaries
        e = set()
        for (a1, b1) in ((lab[:, :-1].ravel(), lab[:, 1:].ravel()),
                         (lab[:-1].ravel(), lab[1:].ravel())):
            m = a1 != b1
            for u, v in zip(a1[m], b1[m]):
                e.add((min(u, v), max(u, v)))
        self.edges = np.array(sorted(e), np.int64) if e else np.zeros((0, 2), np.int64)

    # -- sparse r-hop scale-normalised distance matrices used by the GW term --
    def distance_matrices(self, hops=2):
        n = self.n
        A = sp.coo_matrix((np.ones(len(self.edges)), (self.edges[:, 0], self.edges[:, 1])),
                          shape=(n, n)).tocsr()
        A = ((A + A.T) > 0).astype(np.float64)
        R = A.copy()
        P = A.copy()
        for _ in range(hops - 1):
            P = (P @ A) > 0
            R = ((R + P) > 0).astype(np.float64)
        R.setdiag(0.0); R.eliminate_zeros()
        sT = float(np.median(self.s)) * self.rho
        r = R.tocoo()
        d = np.linalg.norm(self.p[r.row] - self.p[r.col], axis=1) / max(sT, 1e-6)
        D = sp.coo_matrix((d, (r.row, r.col)), shape=(n, n)).tocsr()
        W = sp.coo_matrix((np.ones_like(d), (r.row, r.col)), shape=(n, n)).tocsr()
        D2 = D.copy(); D2.data = D2.data ** 2
        return D, D2, W


# --------------------------------------------------------- canonical descriptors
def canonical_descriptors_multi(g, radii=(2.0, 4.0), **kw):
    """Concatenate canonical descriptors over several patch radii, so that each
    node carries both its own appearance and its local context."""
    return np.hstack([canonical_descriptors(g, radius=r, **kw) for r in radii])


def canonical_descriptors(g: RegionGraph, patch=24, n_ang=8, cells=3, eta=ETA,
                          radius=2.0):
    """Rotation-canonicalised, contrast-invariant orientation-histogram
    descriptor per node; averaged over the two canonical rotations (theta and
    theta+pi) so that the pi-ambiguity of theta is removed (Sect. 3.4.3)."""
    B, H, W = g.img.shape
    u = np.linspace(-radius, radius, patch)
    UU, VV = np.meshgrid(u, u, indexing="ij")          # canonical frame
    descs = []
    for flip in (0.0, np.pi):
        ct, st = np.cos(g.theta + flip), np.sin(g.theta + flip)
        # rotated sampling grid, radius `radius` * s_i
        yy = g.p[:, 0][:, None, None] + g.s[:, None, None] * (ct[:, None, None] * UU - st[:, None, None] * VV)
        xx = g.p[:, 1][:, None, None] + g.s[:, None, None] * (st[:, None, None] * UU + ct[:, None, None] * VV)
        co = np.stack([yy.ravel(), xx.ravel()])
        P = np.stack([map_coordinates(g.img[b], co, order=1, mode="reflect").reshape(g.n, patch, patch)
                      for b in range(B)], 1)             # (n,B,patch,patch)
        # per-patch contrast normalisation
        P = (P - P.mean((2, 3), keepdims=True)) / (P.std((2, 3), keepdims=True) + 1e-6)
        gy = np.zeros_like(P); gx = np.zeros_like(P)
        gy[:, :, 1:-1] = 0.5 * (P[:, :, 2:] - P[:, :, :-2])
        gx[:, :, :, 1:-1] = 0.5 * (P[:, :, :, 2:] - P[:, :, :, :-2])
        mag = np.sqrt(gy ** 2 + gx ** 2)
        w = mag / np.sqrt(mag ** 2 + eta ** 2)          # contrast-invariant weight
        ang = np.mod(np.arctan2(gy, gx), np.pi)
        ab = np.clip((ang / np.pi * n_ang).astype(int), 0, n_ang - 1)
        cy = np.clip((np.arange(patch) / patch * cells).astype(int), 0, cells - 1)
        cell = cy[:, None] * cells + cy[None, :]
        bins = (cell[None, None] * n_ang + ab).reshape(g.n, B, -1)
        ww = w.reshape(g.n, B, -1)
        nb = cells * cells * n_ang
        off = (np.arange(g.n * B) * nb).reshape(g.n, B, 1)
        d = np.bincount((bins + off).ravel(), weights=ww.ravel(),
                        minlength=g.n * B * nb).reshape(g.n, B * nb)
        descs.append(d)
    D = 0.5 * (descs[0] + descs[1])
    D /= np.linalg.norm(D, axis=1, keepdims=True) + 1e-8
    return D


def rank_equalise(D, ref=None):
    """Rank-equalisation of each descriptor dimension (Fig. 2 caption)."""
    base = D if ref is None else ref
    out = np.empty_like(D)
    for c in range(D.shape[1]):
        o = np.argsort(np.argsort(D[:, c]))
        out[:, c] = (o + 0.5) / D.shape[0]
    out -= out.mean(0, keepdims=True)
    out /= np.linalg.norm(out, axis=1, keepdims=True) + 1e-8
    return out


def reduce_dims(Ht, Hy, d=48):
    """Shared PCA of target and reference descriptors, then re-normalisation."""
    A = np.vstack([Ht, Hy])
    A = A - A.mean(0, keepdims=True)
    _, _, Vt = np.linalg.svd(A, full_matrices=False)
    V = Vt[:d].T
    a, b = A[:len(Ht)] @ V, A[len(Ht):] @ V
    a /= np.linalg.norm(a, axis=1, keepdims=True) + 1e-8
    b /= np.linalg.norm(b, axis=1, keepdims=True) + 1e-8
    return a, b


# --------------------------------------------------------------------- FUGW
def normalise_cost(C, mask, lo=1.0, hi=60.0):
    """Monotone rescaling of the feature cost onto [0, ~1] using quantiles over
    the candidate support.  A learned encoder produces a cost that is already on
    this scale; with hand-crafted descriptors the rescaling is what lets one
    fixed (eps, tau) pair mean the same thing on both scenes."""
    v = C[mask]
    a_, b_ = np.percentile(v, lo), np.percentile(v, hi)
    return np.clip((C - a_) / max(b_ - a_, 1e-8), 0.0, None)


def fugw(C, a, b, mask, DT, D2T, WT, DY, D2Y, WY,
         alpha=0.5, eps=0.10, tau=0.15, n_outer=4, n_sink=120):
    """Fused unbalanced Gromov-Wasserstein coupling (7), block-coordinate
    descent with the generalized Sinkhorn scaling (8).

    C     : (nT,nY) feature cost, already restricted to candidates
    mask  : boolean candidate support (C_ij = +inf outside)
    tau   : mass-abstention parameter; tau -> inf gives the balanced problem
    """
    nT, nY = C.shape
    G = (a[:, None] * b[None, :]) * mask
    G /= G.sum() + 1e-30
    phi = tau / (tau + eps)

    for _ in range(n_outer):
        if alpha > 0:
            # L (x) G  =  D2T G WY^T + WT G D2Y^T - 2 DT G DY^T
            L = (D2T @ G) @ WY.T + (WT @ G) @ D2Y.T - 2.0 * ((DT @ G) @ DY.T)
            L = np.asarray(L)
            sc = np.percentile(L[mask], 95) if mask.any() else 1.0
            L = L / max(sc, 1e-8)
            Cc = (1 - alpha) * C + alpha * L
        else:
            Cc = C
        # eps and tau are held fixed across blocks.  The mass rescaling of the
        # quadratic-KL formulation of [12], [13] is not applied: with the
        # hand-crafted cost used for these illustrative figures it is a
        # contraction on the total mass and drives the coupling to zero.
        e_, t_ = eps, tau
        phi = t_ / (t_ + e_)
        # K_ij = a_i b_j exp(-C_ij / eps): the entropic term is KL(G | a (x) b),
        # so the reference product measure belongs inside the kernel.
        K = np.where(mask, np.exp(-np.clip(Cc / max(e_, 1e-8), -60, 60)), 0.0)
        K *= a[:, None] * b[None, :]
        u = np.ones(nT); v = np.ones(nY)
        for _ in range(n_sink):
            u = np.power(a / (K @ v + 1e-300), phi)
            v = np.power(b / (K.T @ u + 1e-300), phi)
        G = u[:, None] * K * v[None, :]
        G = np.nan_to_num(G, nan=0.0, posinf=0.0)
        if G.sum() <= 1e-12:
            break
    return G


def reliability(G, a, calib_q=98.0):
    """Reliability and barycentric assignment of (9).

    m_i = min(1, r_i / a_i) up to one global normalisation constant, taken as
    the `calib_q`-th percentile of r_i / a_i.  The constant absorbs the fact
    that the reference measure b is spread over N_Y >> N_T nodes, so that the
    raw ratio never approaches one; being a single monotone rescaling it leaves
    both the ordering of m and its AUROC unchanged, and it preserves the
    exponential decay of m with the matching cost (Proposition 2).
    """
    r = G.sum(1)
    ratio = r / (a + 1e-30)
    kappa = np.percentile(ratio, calib_q)
    m = np.minimum(1.0, ratio / max(kappa, 1e-30))
    pi = G / (r[:, None] + 1e-30)
    return m, pi, r
