"""Computational cost against reference size (Fig. 18).

(a) Sampling time per 256x256 tile as the reference grows, for the candidate-set
    matcher used by TRUST-Diff and for an exhaustive matcher that scores every
    reference node, which is the cost structure of a sliding-window search.
(b) The one-off reference index build, which is linear in N_Y.
"""
import pickle
import time

import numpy as np
from sklearn.neighbors import NearestNeighbors

from . import cases
from . import matching as M
from . import pcm
from . import prep
from .run import CFG, OUT
from .paths import OUT

SIDES = [256, 384, 512, 640, 768]


def main():
    from .paths import ensure
    ensure()
    h, hwl = prep.load_houston()
    p, pwl = prep.load_pavia()
    rows = []
    ry0, rx0 = cases.HOUSTON_REF[0], cases.HOUSTON_REF[1]

    c0 = cases.houston_case()
    R = c0["R_true"].astype(np.float64)
    hr = c0["hr"].astype(np.float64)
    zy = np.tensordot(R, hr, axes=([1], [0]))
    zy = (zy - zy.min()) / (zy.max() - zy.min())
    ty, tx, _, _ = c0["tgt_rect"]

    # target side of the match, built once
    gT = M.RegionGraph(zy, n_segments=CFG["n_seg_t"])
    dT = M.canonical_descriptors_multi(gT, radii=(2.0, 4.0))
    Ht0 = M.rank_equalise(dT)

    for side in SIDES:
        rows_ = min(side, 349)
        case = prep.build_case("Houston", h, hwl, cases.HOUSTON_TGT,
                               (ry0, rx0, rows_, side),
                               unrelated_cube=p, unrelated_wl=pwl,
                               unrelated_rect=(0, 0, 300, 340), ratio=4,
                               zeta=0.25, warp_amp=3.0, seed=0)
        n_seg = int(CFG["n_seg_y"] * (rows_ * side) / (349 * 540))

        t0 = time.time()
        refg = pcm.ReferenceGraph(case["y"].astype(np.float64), origin=(ry0, rx0),
                                  n_segments=max(n_seg, 300))
        t_index = time.time() - t0

        Hy = M.rank_equalise(refg.desc_raw)
        Ht, Hy = M.reduce_dims(Ht0, Hy, d=48)

        # repeat the timing: at these graph sizes a single measurement is
        # dominated by jitter rather than by the reference size
        REP = 7
        ta, te_ = [], []
        for _ in range(REP):
            t0 = time.time()
            nn = NearestNeighbors(n_neighbors=min(CFG["kc"], refg.n)).fit(Hy)
            nn.kneighbors(Ht)
            ta.append(time.time() - t0)
            t0 = time.time()
            (1.0 - Ht @ Hy.T).argmin(1)
            te_.append(time.time() - t0)
        t_ann, t_exh = float(np.median(ta)), float(np.median(te_))

        rows.append(dict(side=side, n_ref_nodes=refg.n, n_pixels=rows_ * side,
                         t_index=t_index, t_match_ann=t_ann, t_match_exhaustive=t_exh,
                         t_ann_all=ta, t_exh_all=te_))
        print(f"side {side:4d}  N_Y {rows_*side:7d}  nodes {refg.n:6d}  "
              f"index {t_index:6.2f}s  ANN match {t_ann:6.3f}s  "
              f"exhaustive {t_exh:6.3f}s", flush=True)

    with open(f"{OUT}/runtime.pkl", "wb") as f:
        pickle.dump(dict(rows=rows, n_target_nodes=gT.n, cfg=CFG), f)
    print("saved runtime.pkl", flush=True)


if __name__ == "__main__":
    main()
