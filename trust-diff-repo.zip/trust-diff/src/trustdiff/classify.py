"""Downstream classification on the super-resolved Indian Pines scene (Fig. 19,
Table XV).

A fixed classifier is trained once on the ground-truth high-resolution spectra
and then applied unchanged to each super-resolved cube, so the only thing that
varies between rows is the reconstruction.  Indian Pines is used here and not as
a super-resolution dataset: at 145 x 145 it cannot carry a 256^2 target plus a
larger disjoint reference, but it is the only scene here with complete
per-pixel labels.
"""
import pickle
import time

import numpy as np
from sklearn.decomposition import PCA
from sklearn.metrics import cohen_kappa_score, confusion_matrix
from sklearn.model_selection import train_test_split
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from scipy.ndimage import zoom

from . import cases
from . import metrics
from . import pcm
from . import solver
from .run import OUT
from .paths import OUT

# k = 8 is the default of Table III, but Indian Pines is a 16-class agricultural
# scene whose classes differ by subtle spectral detail; a rank-8 subspace throws
# that detail away and the classifier collapses. k = 30 keeps it.
CFG_IP = dict(T=40, M_refresh=13, eta_guide=0.03, tau=0.15, alpha=0.5, kc=24,
              geo_radius=25.0, n_seg_t=500, n_seg_y=1200, k=30)


def features(Z, pca=None):
    """Spectral-spatial features: principal components of the spectra, plus a
    5x5 local mean of those components.  A purely spectral, pixel-wise classifier
    is blind to spatial resolution by construction and would show no difference
    between a blurred and a sharpened cube; the context term is what makes the
    experiment a test of super-resolution at all."""
    from scipy.ndimage import uniform_filter
    C, H, W = Z.shape
    flat = Z.reshape(C, -1).T
    if pca is None:
        pca = PCA(n_components=30, random_state=0).fit(flat)
    P = pca.transform(flat).T.reshape(-1, H, W)
    ctx = uniform_filter(P, size=(0, 5, 5))
    return np.concatenate([P, ctx], 0), pca


def scores(y_true, y_pred):
    oa = float((y_true == y_pred).mean())
    cm = confusion_matrix(y_true, y_pred)
    per = np.divide(np.diag(cm), cm.sum(1), out=np.zeros(cm.shape[0]), where=cm.sum(1) > 0)
    return dict(OA=100 * oa, AA=100 * float(per.mean()),
                kappa=float(cohen_kappa_score(y_true, y_pred)))


def main():
    from .paths import ensure
    ensure()
    c = cases.indian_case()
    hr = c["hr"].astype(np.float64)
    gt = c["gt_labels"]
    nc = c["nc"]
    ry, rx, _, _ = c["ref_rect"]

    refg = pcm.ReferenceGraph(c["y"].astype(np.float64), origin=(ry, rx),
                              n_segments=CFG_IP["n_seg_y"])

    res = {"HR ground truth": hr,
           "Bicubic": np.clip(np.stack([zoom(b, c["ratio"], order=3)
                                        for b in c["lr"].astype(np.float64)]), 0, 1)}
    base = solver.sample(c, mode="noref", T=CFG_IP["T"], k=CFG_IP["k"])
    res["No-reference (A0)"] = base["Z"]
    for mode, label in [("argmax", "Argmax, always transfer"),
                        ("trust", "TRUST-Diff")]:
        t0 = time.time()
        r = solver.sample(c, mode=mode, refg=refg, T=CFG_IP["T"],
                          M_refresh=CFG_IP["M_refresh"], eta_guide=CFG_IP["eta_guide"],
                          tau=CFG_IP["tau"], alpha=CFG_IP["alpha"], kc=CFG_IP["kc"],
                          geo_radius=CFG_IP["geo_radius"], n_seg_t=CFG_IP["n_seg_t"],
                          k=CFG_IP["k"])
        res[label] = r["Z"]
        if mode == "trust":
            rel = r["m"]
        print(f"[ip] {mode}: {time.time()-t0:.0f}s", flush=True)

    # ---- fixed classifier, trained once on the ground truth
    mask = gt > 0
    ys, xs = np.nonzero(mask)
    labels = gt[ys, xs]
    Fgt, pca = features(hr)
    Xgt = Fgt[:, ys, xs].T
    idx_tr, idx_te = train_test_split(np.arange(len(labels)), train_size=0.10,
                                      stratify=labels, random_state=0)
    clf = make_pipeline(StandardScaler(),
                        SVC(C=100.0, gamma="scale", kernel="rbf", random_state=0))
    clf.fit(Xgt[idx_tr], labels[idx_tr])
    print(f"[ip] classifier trained on {len(idx_tr)} of {len(labels)} labelled pixels",
          flush=True)

    table, maps = {}, {}
    for name, Z in res.items():
        F, _ = features(Z, pca)
        Xs = F[:, ys, xs].T
        pred = clf.predict(Xs)
        table[name] = scores(labels[idx_te], pred[idx_te])
        if name != "HR ground truth":
            table[name].update(PSNR=metrics.psnr(Z, hr), SAM=metrics.sam(Z, hr))
        m = np.zeros_like(gt)
        m[ys, xs] = pred
        maps[name] = m
        nc_sel = nc[ys, xs][idx_te]
        table[name]["OA_nc"] = 100 * float(
            (labels[idx_te][nc_sel] == pred[idx_te][nc_sel]).mean()) if nc_sel.any() else np.nan
        print(f"[ip] {name:26s} OA {table[name]['OA']:.1f}  AA {table[name]['AA']:.1f}  "
              f"kappa {table[name]['kappa']:.3f}  OA in nc {table[name]['OA_nc']:.1f}",
              flush=True)

    Ft, _ = features(res["TRUST-Diff"], pca)
    cm = confusion_matrix(labels[idx_te], clf.predict(Ft[:, ys, xs].T)[idx_te],
                          normalize="true")
    with open(f"{OUT}/indian_classify.pkl", "wb") as f:
        pickle.dump(dict(case=c, res=res, maps=maps, table=table, cm=cm,
                         rel=rel, cfg=CFG_IP), f)
    print("saved indian_classify.pkl", flush=True)


if __name__ == "__main__":
    main()
