"""CNC-Bench sweep over the non-correspondence fraction zeta (Fig. 11).

The target and its low-resolution observation do not depend on zeta - only the
reference does - so the no-reference baseline is run once and reused, and the
reference gain of every method is measured against it.  A constant reference
produces a structure-tensor field that is identically zero, so the guidance term
vanishes and the null-reference output coincides with the no-reference output;
RG = PSNR(Y) - PSNR(A0) is therefore exact rather than approximate here.
"""
import os
import pickle
import time

import numpy as np

from . import cases
from . import metrics
from . import pcm
from . import prep
from . import solver
from .run import CFG, OUT
from .paths import OUT

ZETAS = [0.0, 0.1, 0.2, 0.4, 0.6, 0.8]
MODES = ["argmax", "softattn", "trust"]


def main():
    from .paths import ensure
    ensure()
    h, hwl = prep.load_houston()
    p, pwl = prep.load_pavia()
    rows = []

    base_case = prep.build_case("Houston", h, hwl, cases.HOUSTON_TGT, cases.HOUSTON_REF,
                                unrelated_cube=p, unrelated_wl=pwl,
                                unrelated_rect=(0, 0, 300, 340), ratio=4, zeta=0.25,
                                warp_amp=3.0, seed=0)
    hr = base_case["hr"].astype(np.float64)

    t0 = time.time()
    base = solver.sample(base_case, mode="noref", T=CFG["T"], k=CFG["k"])
    psnr0 = metrics.psnr(base["Z"], hr)
    print(f"[zeta] no-reference baseline: {psnr0:.3f} dB  ({time.time()-t0:.0f}s)", flush=True)

    for z in ZETAS:
        c = prep.build_case("Houston", h, hwl, cases.HOUSTON_TGT, cases.HOUSTON_REF,
                            unrelated_cube=p, unrelated_wl=pwl,
                            unrelated_rect=(0, 0, 300, 340), ratio=4, zeta=z,
                            warp_amp=3.0, seed=0)
        nc = c["nc"]
        ry, rx, _, _ = c["ref_rect"]
        refg = pcm.ReferenceGraph(c["y"].astype(np.float64), origin=(ry, rx),
                                  n_segments=CFG["n_seg_y"])
        rows.append(dict(zeta=z, method="noref", PSNR=psnr0, RIH=0.0, RG=0.0,
                         measured_zeta=c["measured_zeta"], nc_frac=float(nc.mean())))
        for mode in MODES:
            t0 = time.time()
            r = solver.sample(c, mode=mode, refg=refg, T=CFG["T"],
                              M_refresh=CFG["M_refresh"], eta_guide=CFG["eta_guide"],
                              tau=CFG["tau"], alpha=CFG["alpha"], kc=CFG["kc"],
                              geo_radius=CFG["geo_radius"], n_seg_t=CFG["n_seg_t"],
                              k=CFG["k"])
            ps = metrics.psnr(r["Z"], hr)
            rih = metrics.rih(r["Z"], base["Z"], nc)
            rows.append(dict(zeta=z, method=mode, PSNR=ps, RIH=rih, RG=ps - psnr0,
                             measured_zeta=c["measured_zeta"], nc_frac=float(nc.mean())))
            print(f"[zeta={z:.1f}] {mode:9s} PSNR {ps:.3f}  RG {ps-psnr0:+.3f}  "
                  f"RIH {rih:.4f}  ({time.time()-t0:.0f}s)", flush=True)

    with open(f"{OUT}/zeta_sweep.pkl", "wb") as f:
        pickle.dump(dict(rows=rows, psnr0=psnr0, cfg=CFG), f)
    print("saved zeta_sweep.pkl", flush=True)


if __name__ == "__main__":
    main()
