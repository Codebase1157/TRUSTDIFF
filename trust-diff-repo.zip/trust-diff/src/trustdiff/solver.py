"""
TRUST-Diff sampling (Algorithm 1) with the reference likelihood of Sect. 3.7.

The frozen 553.8 M-parameter ADM prior of the article cannot be fetched in
this environment, so the denoiser step uses the guided-filter plug-and-play
prior of ops.pnp_denoise.  Everything else -- the spectral subspace, the exact
range-null projection, the partial-correspondence refresh, the contrast-
invariant structure-tensor energy and its projected gradient step -- follows the
manuscript.  The prior is identical for every variant compared, so the
differences between the columns of Figs. 5 and 6 are differences in reference
transfer and nothing else.
"""
import numpy as np
from scipy.ndimage import zoom, gaussian_filter

from . import ops
from . import matching as M
from . import pcm


def _to_unit(x):
    lo, hi = np.percentile(x, 0.5), np.percentile(x, 99.5)
    return np.clip((x - lo) / max(hi - lo, 1e-8), 0.0, 1.0)


def ref_energy_grad(U, E, R, S, mp, good, eta=M.ETA):
    """grad_U of  L_ref(U) = sum_b sum_p m_p (1 - psi_b^T S_b psi_b)   (12)."""
    k, H, W = U.shape
    Z = np.tensordot(E, U, axes=([1], [0]))          # (C,H,W)
    I = np.tensordot(R, Z, axes=([1], [0]))          # (c,H,W)
    nB = I.shape[0]
    G = np.zeros_like(I)
    val = 0.0
    w = mp * good
    for b in range(nB):
        vy, vx = np.gradient(I[b])
        g = vy ** 2 + vx ** 2 + eta ** 2
        s11, s12, s22 = S[3 * b], S[3 * b + 1], S[3 * b + 2]
        Svy = s11 * vy + s12 * vx
        Svx = s12 * vy + s22 * vx
        q = (vy * Svy + vx * Svx) / g
        val += float(np.sum(w * (1.0 - q)))
        cy = -w * (2.0 / g) * (Svy - q * vy)
        cx = -w * (2.0 / g) * (Svx - q * vx)
        G[b] = M.grad_adjoint(cy, cx)
    dZ = np.tensordot(R.T, G, axes=([1], [0]))
    dU = np.tensordot(E.T, dZ, axes=([1], [0]))
    return dU, val


def sample(case, mode="trust", *, k=8, T=60, M_refresh=15, eps=0.10, tau=0.25,
           alpha=0.5, kc=32, geo_radius=60.0, eta_guide=0.08, n_seg_t=900,
           n_seg_y=2600, refg=None, lam=1.0, verbose=True, sigma0=0.45,
           sigma1=0.02, topk=2, use_ref=True, seed=0, refine=10, hook=None):
    """mode in {'noref','trust','balanced','argmax','softattn'}.

    `hook`, when given, is called as hook(t, stage, data) after each stage of
    each reverse step.  It only observes; it never changes the trajectory.  The
    schematic figures use it to show real intermediates rather than mock-ups.
    """
    rng = np.random.default_rng(seed)
    hr = case["hr"].astype(np.float64)
    lr = case["lr"].astype(np.float64)
    C, H, W = hr.shape
    ratio = case["ratio"]

    E, sv = ops.spectral_subspace(lr, k=k)
    D = ops.Degradation((H, W), ratio)
    Xs = np.tensordot(E.T, lr, axes=([1], [0]))       # E^T X   (k,h,w)
    Urg = D.Aplus(Xs)                                  # range part, fixed by data

    def project(U, lam=lam):
        return U + lam * D.Aplus(Xs - D.A(U))

    # ---- initialisation: bicubic lift of the coefficients, then projected
    U = np.stack([zoom(Xs[c], ratio, order=3) for c in range(k)])
    U = project(U)

    R_est = case["R_true"].astype(np.float64)          # nominal response
    refg_local = refg
    state = None
    hist = []

    sig = np.geomspace(sigma0, sigma1, T)
    for t in range(T):
        # (a) prior denoiser  -------------------------------------------------
        U_in = U
        U = ops.pnp_denoise(U, sig[t], guide=U[0])
        if hook is not None:
            hook(t, "pd", dict(U_in=U_in, U_hat=U, sigma=sig[t], E=E))
        # (b) range-null projection  -----------------------------------------
        U_pre = U
        U = project(U)
        if hook is not None:
            hook(t, "rnp", dict(U_pre=U_pre, U_post=U, U_range=Urg,
                                U_null=U_pre - D.Aplus(D.A(U_pre)), E=E))

        if use_ref and mode != "noref":
            # (c) partial-correspondence refresh  -----------------------------
            if t % M_refresh == 0:
                if refg_local is None:
                    ry, rx, _, _ = case["ref_rect"]
                    refg_local = pcm.ReferenceGraph(
                        case["y"].astype(np.float64), origin=(ry, rx),
                        n_segments=n_seg_y)
                Z = np.tensordot(E, U, axes=([1], [0]))
                zy = _to_unit(np.tensordot(R_est, Z, axes=([1], [0])))
                ty, tx, _, _ = case["tgt_rect"]
                out = pcm.refresh(zy, refg_local, (ty, tx),
                                  n_segments=n_seg_t,
                                  mode={"trust": "fugw", "balanced": "balanced",
                                        "argmax": "argmax", "softattn": "softattn"}[mode],
                                  kc=kc, alpha=alpha, eps=eps, tau=tau,
                                  geo_radius=geo_radius)
                S, good = pcm.transport_tensors(out["gT"], out["pi"], out["m"],
                                                refg_local, (H, W), topk=topk,
                                                zy=zy, refine=refine)
                mp = pcm.pixel_reliability(out["gT"], out["m"])
                state = dict(S=S, mp=mp, good=good.astype(float), out=out)
                if hook is not None:
                    hook(t, "pcm", dict(out=out, S=S, mp=mp,
                                        good=good.astype(float), zy=zy,
                                        refg=refg_local))

            # (d) contrast-invariant guidance, projected back  ----------------
            if state is not None:
                dU, val = ref_energy_grad(U, E, R_est, state["S"], state["mp"], state["good"])
                nd = np.linalg.norm(dU) + 1e-12
                step = eta_guide * np.linalg.norm(U) / nd
                U_before = U
                U = project(U - step * dU)
                hist.append(val)
                if hook is not None:
                    hook(t, "sg", dict(U_before=U_before, U_after=U,
                                       energy=val, E=E))

    Z = np.tensordot(E, project(U, lam=1.0), axes=([1], [0]))
    eLR = float(np.linalg.norm(D.A(Z) - lr) / np.linalg.norm(lr))
    if hook is not None:
        hook(T, "final", dict(Z=np.clip(Z, 0, 1), eLR=eLR, E=E))
    res = dict(Z=np.clip(Z, 0, 1), eLR=eLR, E=E, sv=sv, refg=refg_local)
    if state is not None:
        res["m"] = state["mp"]
        res["pcm"] = state["out"]
    return res
