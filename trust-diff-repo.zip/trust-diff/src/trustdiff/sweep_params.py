"""Parameter sensitivity (Fig. 17): subspace dimension k, reverse steps T,
entropic regularisation eps and mass abstention tau, on both scenes.

The tau panel is the experiment that tests H2: Proposition 2 predicts that the
transfer bound decays at rate 1/(tau + eps), so lowering tau at fixed eps should
lower RIH monotonically.
"""
import pickle
import time

import numpy as np

from . import cases
from . import metrics
from . import pcm
from . import solver
from .run import CFG, OUT
from .paths import OUT

GRID = {
    "k":   [3, 5, 8, 12],
    "T":   [20, 40, 60],
    "eps": [0.05, 0.10, 0.20],
    "tau": [0.05, 0.10, 0.15, 0.30],
}
DEFAULT = {"k": CFG["k"], "T": CFG["T"], "eps": 0.10, "tau": CFG["tau"]}


def main():
    from .paths import ensure
    ensure()
    out = {}
    for tag, builder in [("houston", cases.houston_case), ("pavia", cases.pavia_case)]:
        c = builder()
        hr = c["hr"].astype(np.float64)
        nc = c["nc"]
        ry, rx, _, _ = c["ref_rect"]
        refg = pcm.ReferenceGraph(c["y"].astype(np.float64), origin=(ry, rx),
                                  n_segments=CFG["n_seg_y"])
        base = solver.sample(c, mode="noref", T=CFG["T"], k=CFG["k"])
        cache = {}

        def run(**over):
            cfg = dict(DEFAULT); cfg.update(over)
            key = tuple(sorted(cfg.items()))
            if key in cache:
                return cache[key]
            t0 = time.time()
            r = solver.sample(c, mode="trust", refg=refg, k=cfg["k"], T=cfg["T"],
                              eps=cfg["eps"], tau=cfg["tau"],
                              M_refresh=max(cfg["T"] // 3, 5),
                              eta_guide=CFG["eta_guide"], alpha=CFG["alpha"],
                              kc=CFG["kc"], geo_radius=CFG["geo_radius"],
                              n_seg_t=CFG["n_seg_t"])
            # the no-reference run for RIH must use the same k
            b = base if cfg["k"] == CFG["k"] else solver.sample(c, mode="noref",
                                                                T=cfg["T"], k=cfg["k"])
            v = dict(PSNR=metrics.psnr(r["Z"], hr),
                     RIH=metrics.rih(r["Z"], b["Z"], nc),
                     SAM=metrics.sam(r["Z"], hr))
            cache[key] = v
            print(f"[{tag}] {over}  PSNR {v['PSNR']:.3f}  RIH {v['RIH']:.4f}  "
                  f"({time.time()-t0:.0f}s)", flush=True)
            return v

        res = {}
        for name, values in GRID.items():
            res[name] = [(v, run(**{name: v})) for v in values]
        out[tag] = dict(res=res, default=DEFAULT,
                        noref=dict(PSNR=metrics.psnr(base["Z"], hr)))

    with open(f"{OUT}/param_sweep.pkl", "wb") as f:
        pickle.dump(out, f)
    print("saved param_sweep.pkl", flush=True)


if __name__ == "__main__":
    main()
