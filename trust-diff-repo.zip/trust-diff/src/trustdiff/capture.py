"""Capture the real intermediates that the three schematic figures show.

Figs. 1-3 of the article are explanatory diagrams, but every image panel in
them is a real array taken from a real run: this module runs the sampler once on
the Pavia case with an observation hook, runs one matching refresh on the
ground-truth target for Fig. 2, and builds the two training views for Fig. 3.
Only small arrays (RGB renderings, 2-D maps, sub-sampled matrices) are kept, so
the cache stays a few megabytes.
"""
import os
import pickle

import numpy as np
from scipy.ndimage import zoom

from . import cases
from . import matching as M
from . import pcm
from . import prep
from . import solver
from .paths import CACHE, OUT


CACHE = f"{OUT}/schematics.pkl"


def rgb(cube, wl=None, bands=None, p=(2, 98)):
    if bands is None:
        idx = lambda t: int(np.argmin(np.abs(wl - t)))
        bands = (idx(660), idx(560), idx(480))
    im = np.stack([cube[b] for b in bands], -1).astype(float)
    lo, hi = np.percentile(im, p[0]), np.percentile(im, p[1])
    return np.clip((im - lo) / max(hi - lo, 1e-8), 0, 1).astype(np.float32)


def coef_rgb(U, E, wl):
    Z = np.tensordot(E, U, axes=([1], [0]))
    return rgb(Z, wl)


# ------------------------------------------------------------------ Fig. 1
def capture_sampling(case, cfg, snaps=(0, 13, 26, 39)):
    wl = case["wl"]
    store = {"snap": {}, "stage": {}}
    ry, rx, _, _ = case["ref_rect"]
    refg = pcm.ReferenceGraph(case["y"].astype(np.float64), origin=(ry, rx),
                              n_segments=cfg["n_seg_y"])

    def hook(t, stage, d):
        if stage == "pd" and t in snaps:
            store["snap"][t] = dict(
                before=coef_rgb(d["U_in"], d["E"], wl),
                after=coef_rgb(d["U_hat"], d["E"], wl),
                sigma=float(d["sigma"]))
        if stage == "pd" and t == 0:
            store["stage"]["pd"] = dict(
                noisy=coef_rgb(d["U_in"], d["E"], wl),
                denoised=coef_rgb(d["U_hat"], d["E"], wl),
                sigma=float(d["sigma"]))
        if stage == "rnp" and t == 0:
            store["stage"]["rnp"] = dict(
                rng=coef_rgb(d["U_range"], d["E"], wl),
                null=coef_rgb(d["U_null"], d["E"], wl),
                total=coef_rgb(d["U_post"], d["E"], wl))
        if stage == "pcm" and t == 0:
            o = d["out"]
            g = o["G"]
            store["stage"]["pcm"] = dict(
                m=o["m"].astype(np.float32),
                mp=d["mp"].astype(np.float32),
                lab=d["out"]["gT"].lab.astype(np.int32),
                p=d["out"]["gT"].p.astype(np.float32),
                zy=rgb(d["zy"], bands=(2, 1, 0)),
                Gsub=g[:160, :160].astype(np.float32),
                rowmass=g.sum(1).astype(np.float32),
                a=d["out"]["gT"].a.astype(np.float32))
        if stage == "sg" and t == 1:
            store["stage"]["sg"] = dict(
                before=coef_rgb(d["U_before"], d["E"], wl),
                after=coef_rgb(d["U_after"], d["E"], wl),
                energy=float(d["energy"]))
        if stage == "final":
            store["final"] = dict(Z=rgb(d["Z"], wl), eLR=float(d["eLR"]))

    r = solver.sample(case, mode="trust", refg=refg, T=cfg["T"],
                      M_refresh=cfg["M_refresh"], eta_guide=cfg["eta_guide"],
                      tau=cfg["tau"], alpha=cfg["alpha"], kc=cfg["kc"],
                      geo_radius=cfg["geo_radius"], n_seg_t=cfg["n_seg_t"],
                      k=cfg["k"], hook=hook)
    store["m_final"] = r["m"].astype(np.float32)
    return store, refg


# ------------------------------------------------------------------ Fig. 2
def capture_matching(case, cfg, refg):
    """One refresh on the ground-truth target, which is the configuration the
    schematic illustrates (Sect. 5.5.3 reports both this and the in-sampler
    value)."""
    from sklearn.metrics import roc_auc_score
    hr = case["hr"].astype(np.float64)
    R = case["R_true"].astype(np.float64)
    zy = np.tensordot(R, hr, axes=([1], [0]))
    zy = (zy - zy.min()) / (zy.max() - zy.min())
    ty, tx, _, _ = case["tgt_rect"]
    out = pcm.refresh(zy, refg, (ty, tx), n_segments=cfg["n_seg_t"],
                      mode="fugw", kc=cfg["kc"], alpha=cfg["alpha"],
                      tau=cfg["tau"], geo_radius=cfg["geo_radius"])
    gT, G, m = out["gT"], out["G"], out["m"]
    nc = case["nc"]
    node_nc = np.array([nc[gT.lab == i].mean() > 0.5 for i in range(gT.n)])
    auroc = float(roc_auc_score(node_nc, 1.0 - m))
    mp = pcm.pixel_reliability(gT, m)

    # A readable sub-block of the plan: the 120 regions that carry the most
    # transported mass, against the reference nodes they actually choose,
    # ordered so that the accepted assignments fall on the diagonal.  The last
    # column is the mass each region kept, i.e. the dustbin.
    rows = np.argsort(-G.sum(1))[:120]
    cols, seen = [], set()
    for i in rows:
        j = int(np.argmax(G[i]))
        if j not in seen:
            seen.add(j); cols.append(j)
    cols = np.array(cols)
    sub = G[np.ix_(rows, cols)]
    csub = out["C"][np.ix_(rows, cols)]
    csub = np.where(np.isfinite(csub), csub, np.nanmax(csub[np.isfinite(csub)]))
    dust_rows = np.maximum(gT.a[rows] - G[rows].sum(1), 0)
    return dict(
        target_rgb=rgb(zy, bands=(2, 1, 0)),
        ref_rgb=rgb(case["y"], bands=(2, 1, 0)),
        lab=gT.lab.astype(np.int32), p=gT.p.astype(np.float32),
        s=gT.s.astype(np.float32), theta=gT.theta.astype(np.float32),
        edges=np.asarray(gT.edges, np.int32),
        m=m.astype(np.float32), mp=mp.astype(np.float32),
        node_nc=node_nc, auroc=auroc,
        C=csub.astype(np.float32),
        Gsub=sub.astype(np.float32),
        dust=dust_rows.astype(np.float32),
        nc=nc, nc_ref=case["nc_ref"],
        n_target=int(gT.n), n_ref=int(refg.n),
        ref_rect=case["ref_rect"], tgt_rect=case["tgt_rect"])


# ------------------------------------------------------------------ Fig. 3
def capture_training(seed=7):
    """Two views of an unlabelled HR MSI tile, the known partial ground truth
    they induce, and the two assignment targets the figure contrasts."""
    p, pwl = prep.load_pavia()
    h, hwl = prep.load_houston()
    rng = np.random.default_rng(seed)

    tile = prep.robust_scale(p[0:200, 0:200, :]).transpose(2, 0, 1)
    R, _ = prep.simulated_srf(pwl)
    I = prep.robust_scale(np.tensordot(R, tile, axes=([1], [0])))

    v1, _ = prep.radiometric_change(I, np.random.default_rng(seed + 1))
    v1 = prep.robust_scale(v1)

    un = prep.robust_scale(h[40:240, 1100:1300, :]).transpose(2, 0, 1)
    Ru, _ = prep.simulated_srf(hwl)
    un4 = prep.robust_scale(np.tensordot(Ru, un, axes=([1], [0])))
    mask = prep.blob_mask(I.shape[1:], 0.22, rng, smooth=I.shape[1] / 18.0)
    comp = I * (~mask)[None] + un4[:, :I.shape[1], :I.shape[2]] * mask[None]
    dy, dx = prep.tps_field(I.shape[1:], n_ctrl=4, amp=4.0, rng=rng)
    v2 = prep.apply_backward_warp(comp, dy, dx)
    v2, _ = prep.radiometric_change(v2, np.random.default_rng(seed + 2))
    v2 = prep.robust_scale(v2)

    g1 = M.RegionGraph(v1, n_segments=140)
    g2 = M.RegionGraph(v2, n_segments=140)
    # partial ground truth: a node of view 1 is matched when its centroid maps,
    # under the known warp, into a node of view 2 outside the pasted mask
    from scipy.ndimage import map_coordinates
    yy = np.clip(g1.p[:, 0], 0, I.shape[1] - 1)
    xx = np.clip(g1.p[:, 1], 0, I.shape[2] - 1)
    inside = mask[yy.astype(int), xx.astype(int)]
    matched = ~inside
    return dict(v1=np.moveaxis(v1[:3], 0, -1), v2=np.moveaxis(v2[:3], 0, -1),
                src=np.moveaxis(I[:3], 0, -1),
                un=np.moveaxis(un4[:3, :I.shape[1], :I.shape[2]], 0, -1),
                mask=mask, dy=dy, dx=dx,
                p1=g1.p.astype(np.float32), p2=g2.p.astype(np.float32),
                lab1=g1.lab.astype(np.int32), lab2=g2.lab.astype(np.int32),
                edges1=np.asarray(g1.edges, np.int32),
                matched=matched, n1=int(g1.n), n2=int(g2.n))


def main():
    from .paths import ensure
    ensure()
    from run import CFG
    cfg = dict(CFG)
    case = cases.pavia_case()
    print("sampling with hook ...", flush=True)
    samp, refg = capture_sampling(case, cfg)
    print("matching on the ground-truth target ...", flush=True)
    match = capture_matching(case, cfg, refg)
    print(f"  AUROC {match['auroc']:.3f}, {match['n_target']} target nodes, "
          f"{match['n_ref']} reference nodes", flush=True)
    print("training views ...", flush=True)
    train = capture_training()
    print(f"  {train['n1']} / {train['n2']} regions, "
          f"{int(train['matched'].sum())} matched, "
          f"{int((~train['matched']).sum())} unmatched", flush=True)
    with open(CACHE, "wb") as f:
        pickle.dump(dict(samp=samp, match=match, train=train, case_name="Pavia",
                         cfg=cfg), f, protocol=4)
    print("wrote", CACHE, os.path.getsize(CACHE) // 1024, "kB")


if __name__ == "__main__":
    main()
