"""Where the data, the cached results and the figures live.

Every path can be overridden by an environment variable, so the package runs
unchanged from a checkout, a container or a cluster job:

    TRUSTDIFF_DATA     raw cubes                     (default ./data)
    TRUSTDIFF_OUT      cached run results            (default ./results)
    TRUSTDIFF_FIGURES  rendered figures              (default ./figures)
"""
import os
from pathlib import Path

ROOT = Path(os.environ.get("TRUSTDIFF_ROOT", Path.cwd()))

DATA = str(Path(os.environ.get("TRUSTDIFF_DATA", ROOT / "data")))
OUT = str(Path(os.environ.get("TRUSTDIFF_OUT", ROOT / "results")))
FIG = str(Path(os.environ.get("TRUSTDIFF_FIGURES", ROOT / "figures")))
CACHE = os.path.join(OUT, "schematics.pkl")


def ensure():
    for p in (OUT, FIG):
        os.makedirs(p, exist_ok=True)
    return DATA, OUT, FIG
