"""
Construction of the evaluation cases from the public cubes:

    houston/data.mat            Houston 2013, CASI, 349 x 1905 x 144, 380-1050 nm
    pavia/PaviaU.mat            Pavia University, ROSIS, 610 x 340 x 103, 430-860 nm
    indian/indianpinearray.npy  Indian Pines, AVIRIS, 145 x 145 x 200

Everything here follows Sect. 5.1 of the article: the Wald protocol, the four
simulated spectral responses, a thin-plate-spline warp, a radiometric
perturbation, and replaced blobs that give a ground-truth non-correspondence
mask.  The content pasted in to emulate land-cover change is taken from the
*other* cube, so it comes from a different sensor over a different city, which
is a stronger non-correspondence than a second window of the same scene.
"""
import numpy as np
import scipy.io as sio
from scipy.ndimage import gaussian_filter, map_coordinates, binary_dilation, binary_fill_holes
from .paths import DATA


# ----------------------------------------------------------------------------- loading
def load_houston():
    c = sio.loadmat(f"{DATA}/houston/data.mat")["data"].astype(np.float32)
    wl = np.linspace(380.0, 1050.0, c.shape[2])          # CASI VNIR, 144 bands
    return c, wl


def load_indian():
    """Indian Pines, AVIRIS, 145 x 145 x 200 (water-absorption bands removed),
    with its 16-class ground truth.  Supplied as .npy rather than .mat."""
    c = np.load(f"{DATA}/indian/indianpinearray.npy").astype(np.float32)
    g = np.load(f"{DATA}/indian/IPgt.npy").astype(np.int16)
    wl = np.linspace(400.0, 2500.0, c.shape[2])
    return c, wl, g


def load_pavia():
    c = sio.loadmat(f"{DATA}/pavia/PaviaU.mat")["paviaU"].astype(np.float32)
    wl = np.linspace(430.0, 860.0, c.shape[2])           # ROSIS, 103 bands
    return c, wl


def robust_scale(cube, lo=1.0, hi=99.0):
    """Per-cube robust scaling to [0,1]; used for the multispectral reference,
    where visual contrast matters and the matcher is contrast-invariant."""
    a, b = np.percentile(cube, lo), np.percentile(cube, hi)
    return np.clip((cube - a) / max(b - a, 1e-6), 0.0, 1.0).astype(np.float32)


def max_scale(cube, q=99.99):
    """Radiometric scaling of a hyperspectral cube to [0,1] by its own maximum,
    which is the convention under which the PSNR values of Tables V-VI are
    reported."""
    m = np.percentile(cube, q)
    return np.clip(cube / max(m, 1e-6), 0.0, 1.0).astype(np.float32)


# ----------------------------------------------------------------------------- Wald protocol
def gaussian_psf_sigma(ratio):
    """Gaussian PSF whose FWHM equals the spatial ratio (Sect. 5.1)."""
    return ratio / (2.0 * np.sqrt(2.0 * np.log(2.0)))


def wald_degrade(hr, ratio):
    """hr: (C,H,W) -> lr: (C,H/r,W/r).  Gaussian PSF matched to the ratio,
    then uniform decimation.  Matches operator A used by the sampler."""
    sig = gaussian_psf_sigma(ratio)
    blur = gaussian_filter(hr, sigma=(0, sig, sig), mode="wrap")
    off = ratio // 2
    return np.ascontiguousarray(blur[:, off::ratio, off::ratio])


# ----------------------------------------------------------------------------- spectral responses
def simulated_srf(wl, centres=(480.0, 560.0, 660.0, 830.0), widths=(60.0, 60.0, 60.0, 120.0)):
    """Four Gaussian multispectral bands (blue, green, red, NIR) -> R in R^{4xC}.
    Centres outside the cube's range are clipped into it so the response stays
    non-degenerate for the 430-860 nm ROSIS cube as well."""
    lo, hi = wl.min() + 15.0, wl.max() - 15.0
    R = np.zeros((len(centres), len(wl)), np.float32)
    used = []
    for b, (c0, w) in enumerate(zip(centres, widths)):
        c = float(np.clip(c0, lo, hi))
        used.append(c)
        R[b] = np.exp(-0.5 * ((wl - c) / (w / 2.355)) ** 2)
        R[b] /= R[b].sum()
    return R, np.array(used)


# ----------------------------------------------------------------------------- warp / radiometry
def tps_field(shape, n_ctrl=4, amp=3.0, rng=None):
    """Smooth thin-plate-spline-like displacement field (dy,dx) on `shape`.
    Built as a random control grid upsampled by a thin-plate radial kernel,
    which is what Sect. 5.1 calls for and is smooth by construction."""
    rng = rng or np.random.default_rng(0)
    H, W = shape
    cy = np.linspace(0, H - 1, n_ctrl)
    cx = np.linspace(0, W - 1, n_ctrl)
    CY, CX = np.meshgrid(cy, cx, indexing="ij")
    P = np.stack([CY.ravel(), CX.ravel()], 1)
    V = rng.normal(0.0, amp, size=(P.shape[0], 2))

    def U(r2):
        r2 = np.maximum(r2, 1e-12)
        return r2 * 0.5 * np.log(r2)

    # solve TPS coefficients
    d2 = ((P[:, None, :] - P[None, :, :]) ** 2).sum(-1)
    K = U(d2)
    Pa = np.hstack([np.ones((P.shape[0], 1)), P])
    n = P.shape[0]
    L = np.zeros((n + 3, n + 3))
    L[:n, :n] = K
    L[:n, n:] = Pa
    L[n:, :n] = Pa.T
    Y = np.zeros((n + 3, 2))
    Y[:n] = V
    W_ = np.linalg.solve(L + 1e-8 * np.eye(n + 3), Y)

    yy, xx = np.mgrid[0:H, 0:W]
    Q = np.stack([yy.ravel(), xx.ravel()], 1).astype(np.float64)
    d2q = ((Q[:, None, :] - P[None, :, :]) ** 2).sum(-1)
    F = U(d2q) @ W_[:n] + np.hstack([np.ones((Q.shape[0], 1)), Q]) @ W_[n:]
    return F[:, 0].reshape(H, W).astype(np.float32), F[:, 1].reshape(H, W).astype(np.float32)


def apply_backward_warp(img, dy, dx):
    """img: (B,H,W). Samples img at (y+dy, x+dx): the *backward* (sampling) map."""
    B, H, W = img.shape
    yy, xx = np.mgrid[0:H, 0:W].astype(np.float32)
    co = np.stack([yy + dy, xx + dx])
    return np.stack([map_coordinates(img[b], co, order=1, mode="reflect") for b in range(B)])


def radiometric_change(y, rng):
    """Per-band monotone tone curve + smooth illumination field + haze offset.
    Strictly monotone per band, so the contrast-invariant likelihood of
    Sect. 3.7 is blind to it by construction."""
    B, H, W = y.shape
    out = np.empty_like(y)
    gammas, gains, hazes = [], [], []
    for b in range(B):
        g = float(rng.uniform(0.60, 1.65))               # monotone tone curve
        k = float(rng.uniform(0.75, 1.35))               # band gain
        h = float(rng.uniform(0.00, 0.10))               # additive haze
        gammas.append(g); gains.append(k); hazes.append(h)
        out[b] = k * np.power(np.clip(y[b], 0, 1), g) + h
    # smooth multiplicative illumination field, shared across bands
    f = rng.normal(0, 1, (8, 8)).astype(np.float32)
    f = map_coordinates(f, np.stack(np.meshgrid(
        np.linspace(0, 7, H), np.linspace(0, 7, W), indexing="ij")), order=1, mode="nearest")
    f = gaussian_filter(f, 12.0)
    f = 1.0 + 0.25 * f / (np.abs(f).max() + 1e-8)
    out *= f[None]
    return np.clip(out, 0, None).astype(np.float32), dict(gamma=gammas, gain=gains, haze=hazes)


def blob_mask(shape, frac, rng, n_blobs=5, smooth=9.0):
    """Irregular smooth blobs covering approximately `frac` of the area
    (Sect. 5.1 / Fig. 4f: the masks follow the replacement blobs and are
    therefore irregular)."""
    H, W = shape
    field = rng.normal(0, 1, (H, W)).astype(np.float32)
    field = gaussian_filter(field, smooth)
    # pick threshold so the covered fraction matches frac
    thr = np.quantile(field, 1.0 - frac)
    m = field > thr
    if frac <= 0.5:                 # closing holes at high frac swallows the scene
        m = binary_fill_holes(m)
    return m


# ----------------------------------------------------------------------------- case builder
def build_case(name, cube, wl, tgt_rect, ref_rect, unrelated_cube, unrelated_wl,
               unrelated_rect, ratio=4, zeta=0.25, warp_amp=3.0, seed=0,
               srf_centres=(480.0, 560.0, 660.0, 830.0)):
    """Assemble one evaluation case.

    tgt_rect / ref_rect are (row0, col0, nrows, ncols) in scene coordinates.
    The reference window is larger than and partially overlaps the target, as in
    the unpaired setting of Sect. 3.1 (N_Y >> N).
    """
    rng = np.random.default_rng(seed)

    ty, tx, th, tw = tgt_rect
    ry, rx, rh, rw = ref_rect

    hr = max_scale(cube[ty:ty + th, tx:tx + tw, :]).transpose(2, 0, 1).copy()      # (C,H,W)
    C, H, W = hr.shape
    lr = wald_degrade(hr, ratio)

    # ---- reference: disjoint / partially overlapping window of the same scene
    ref_hs = robust_scale(cube[ry:ry + rh, rx:rx + rw, :]).transpose(2, 0, 1)
    R, centres = simulated_srf(wl, centres=srf_centres)
    y_clean = np.tensordot(R, ref_hs, axes=([1], [0])).astype(np.float32)          # (4,rh,rw)
    y_clean = robust_scale(y_clean)

    # ---- replaced blobs (land-cover change / unrelated area), in scene coords
    # The composite is formed BEFORE the warp and BEFORE the radiometric draw, so
    # the replaced content is subject to the same geometry and the same tone
    # curves as the rest of the reference.  Non-correspondence is then purely
    # structural: it cannot be found by a colour threshold.
    if zeta > 0:
        uy, ux, uh, uw = unrelated_rect
        un = robust_scale(unrelated_cube[uy:uy + uh, ux:ux + uw, :]).transpose(2, 0, 1)
        Ru, _ = simulated_srf(unrelated_wl, centres=srf_centres)
        un4 = robust_scale(np.tensordot(Ru, un, axes=([1], [0])).astype(np.float32))
        reps = (1, int(np.ceil(rh / un4.shape[1])), int(np.ceil(rw / un4.shape[2])))
        un4 = np.tile(un4, reps)[:, :rh, :rw]
        M = blob_mask((rh, rw), zeta, rng, smooth=max(rh, rw) / 22.0)
        y_comp = y_clean * (~M)[None] + un4 * M[None]
        measured_zeta = float(M.mean())
    else:
        M = np.zeros((rh, rw), bool)
        y_comp = y_clean
        measured_zeta = 0.0

    # ---- geometric perturbation (thin-plate spline, known)
    dy, dx = tps_field((rh, rw), n_ctrl=4, amp=warp_amp, rng=rng)
    y_warp = apply_backward_warp(y_comp, dy, dx)

    # ---- radiometric perturbation (one draw for the whole reference)
    y, radinfo = radiometric_change(y_warp, rng)
    y = robust_scale(y)

    # ---- ground-truth non-correspondence mask in TARGET coordinates
    # The blob mask M lives in un-warped reference-window coordinates, which are
    # scene coordinates offset by (ry, rx).  A target pixel whose scene location
    # falls inside M therefore has no valid counterpart anywhere in Y.
    nc_scene = np.zeros(cube.shape[:2], bool)
    nc_scene[ry:ry + rh, rx:rx + rw] = M
    nc = nc_scene[ty:ty + th, tx:tx + tw].copy()

    # target pixels with no counterpart at all (outside the reference footprint)
    yy, xx = np.mgrid[ty:ty + th, tx:tx + tw]
    outside = ~((yy >= ry) & (yy < ry + rh) & (xx >= rx) & (xx < rx + rw))
    nc |= outside

    return dict(
        name=name, ratio=ratio, wl=wl, R_true=R, srf_centres=centres,
        hr=hr, lr=lr, y=y, nc=nc, nc_ref=M, measured_zeta=measured_zeta,
        tgt_rect=tgt_rect, ref_rect=ref_rect, warp=(dy, dx), radinfo=radinfo,
        overlap_frac=float((~outside).mean()),
    )
