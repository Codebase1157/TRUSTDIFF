"""Full-reference and trust metrics of Sect. 5.3."""
import numpy as np
from skimage.metrics import structural_similarity


def psnr(z, gt, mask=None):
    e = (z - gt) ** 2
    e = e.mean(0)[mask] if mask is not None else e
    return float(10 * np.log10(1.0 / max(e.mean(), 1e-30)))


def rmse(z, gt):
    return float(np.sqrt(np.mean((z - gt) ** 2)))


def ssim(z, gt):
    v = [structural_similarity(gt[b], z[b], data_range=1.0) for b in range(gt.shape[0])]
    return float(np.mean(v))


def sam(z, gt, deg=True, per_pixel=False):
    num = (z * gt).sum(0)
    den = np.sqrt((z ** 2).sum(0)) * np.sqrt((gt ** 2).sum(0)) + 1e-12
    a = np.arccos(np.clip(num / den, -1, 1))
    if per_pixel:
        return np.degrees(a) if deg else a
    return float(np.degrees(a).mean() if deg else a.mean())


def cc(z, gt):
    v = []
    for b in range(gt.shape[0]):
        x, y = z[b].ravel() - z[b].mean(), gt[b].ravel() - gt[b].mean()
        v.append(float((x @ y) / (np.linalg.norm(x) * np.linalg.norm(y) + 1e-12)))
    return float(np.mean(v))


def ergas(z, gt, ratio):
    C = gt.shape[0]
    t = 0.0
    for b in range(C):
        mu = gt[b].mean() + 1e-12
        t += np.mean((z[b] - gt[b]) ** 2) / mu ** 2
    return float(100.0 / ratio * np.sqrt(t / C))


def rih(z_ref, z_null, mask):
    """Reference-induced hallucination (17), restricted to Omega_nc."""
    d = (z_ref - z_null) * mask[None]
    n = z_null * mask[None]
    return float(np.linalg.norm(d) / (np.linalg.norm(n) + 1e-12))


def ece(m, y, bins=10):
    """Expected calibration error of the reliability map against the
    correspondence indicator, over equal-width bins."""
    m = m.ravel(); y = y.ravel().astype(float)
    edges = np.linspace(0, 1, bins + 1)
    e, tot, curve = 0.0, m.size, []
    for i in range(bins):
        s = (m >= edges[i]) & (m < edges[i + 1] if i < bins - 1 else m <= 1.0)
        if s.sum() == 0:
            curve.append((np.nan, np.nan, 0)); continue
        conf, acc = m[s].mean(), y[s].mean()
        e += s.sum() / tot * abs(acc - conf)
        curve.append((conf, acc, int(s.sum())))
    return float(e), curve


def summarise(z, gt, ratio, nc=None):
    d = dict(PSNR=psnr(z, gt), SSIM=ssim(z, gt), SAM=sam(z, gt),
             ERGAS=ergas(z, gt, ratio), CC=cc(z, gt), RMSE=rmse(z, gt))
    if nc is not None:
        d["PSNR_valid"] = psnr(z, gt, ~nc)
        d["PSNR_nc"] = psnr(z, gt, nc)
    return d
