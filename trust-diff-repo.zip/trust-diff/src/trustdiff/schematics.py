"""Figs. 1-3: the three explanatory diagrams, redrawn.

Design rules for these three, which differ from the result figures:

  * every character is black.  Colour is carried only by data - the images, the
    transport matrices, the two graph node sets - and everything coloured is
    also named in words, so the figures survive a greyscale print;
  * the figures carry labels, not prose.  Type is set at 9 pt for panel
    headings and 7.5-8 pt for labels at the final printed width of 6.5 in, which
    is the text block; the explanation lives in the caption, where a reader can
    take it at reading size;
  * every image panel is a real array from a real run, captured by capture.py.

Rendered at 600 dpi.
"""
import os
import pickle

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch, Circle
from matplotlib.colors import LinearSegmentedColormap
from .paths import CACHE, FIG


INK = "#000000"
RULE = "#3a3a3a"
SOFT = "#b4b3af"
FILL = "#f4f3f0"
FILL2 = "#e6e5e1"
BLUE = "#2a78d6"
ORANGE = "#eb6834"
AQUA = "#1baf7a"
SEQ = LinearSegmentedColormap.from_list(
    "seq", ["#ffffff", "#d7e7fb", "#a8cbf5", "#6da7ec", "#2a78d6", "#18508f"])

HEAD = dict(color=INK, fontsize=9.0, fontweight="bold")
LAB = dict(color=INK, fontsize=8.0)
SM = dict(color=INK, fontsize=7.4)


def rc():
    matplotlib.rcParams.update({
        "figure.facecolor": "white", "savefig.facecolor": "white",
        "font.family": "DejaVu Sans", "font.size": 8.0,
        "text.color": INK, "axes.labelcolor": INK,
        "mathtext.fontset": "dejavusans",
        "pdf.fonttype": 42, "ps.fonttype": 42,
    })


def stretch(rgb, lo=1.5, hi=98.5, joint=False):
    """Robust contrast stretch.  Joint keeps the colour balance of the source
    and is what the result figures use; per-channel is used where two panels
    differ only in radiometry and have to stay comparable on the page."""
    out = np.array(rgb, float)
    if joint:
        a, b = np.percentile(out, lo), np.percentile(out, hi)
        return np.clip((out - a) / max(b - a, 1e-8), 0, 1)
    for c in range(out.shape[-1]):
        a, b = np.percentile(out[..., c], lo), np.percentile(out[..., c], hi)
        out[..., c] = np.clip((out[..., c] - a) / max(b - a, 1e-8), 0, 1)
    return out


class Sheet:
    """A drawing sheet whose units are 1/20 in, with image panels on top."""

    def __init__(self, w_in, h_in):
        self.fig = plt.figure(figsize=(w_in, h_in))
        self.ax = self.fig.add_axes([0, 0, 1, 1])
        self.W, self.H = w_in * 20.0, h_in * 20.0
        self.ax.set_xlim(0, self.W); self.ax.set_ylim(0, self.H)
        self.ax.set_axis_off()

    def box(self, x, y, w, h, fc=FILL, ec=RULE, lw=0.8, r=1.0, ls="-", z=1):
        self.ax.add_patch(FancyBboxPatch(
            (x, y), w, h, boxstyle=f"round,pad=0,rounding_size={r}",
            fc=fc, ec=ec, lw=lw, linestyle=ls, zorder=z))

    def t(self, x, y, s, ha="left", va="bottom", style=None, **kw):
        st = dict(style or LAB); st.update(kw)
        return self.ax.text(x, y, s, ha=ha, va=va, zorder=6, **st)

    def head(self, x, y, s, ha="left", va="top", **kw):
        return self.t(x, y, s, ha, va, style=HEAD, linespacing=1.3, **kw)

    def arrow(self, p0, p1, lw=1.1, style="-|>", ls="-", color=INK, rad=0.0):
        self.ax.add_patch(FancyArrowPatch(
            p0, p1, arrowstyle=style, mutation_scale=8, lw=lw, color=color,
            linestyle=ls, shrinkA=0, shrinkB=0, zorder=5,
            connectionstyle=f"arc3,rad={rad}"))

    def _axes(self, x, y, w, h, z=3):
        self.fig.canvas.draw()
        inv = self.fig.transFigure.inverted()
        x0, y0 = inv.transform(self.ax.transData.transform((x, y)))
        x1, y1 = inv.transform(self.ax.transData.transform((x + w, y + h)))
        a = self.fig.add_axes([x0, y0, x1 - x0, y1 - y0], zorder=z)
        a.set_xticks([]); a.set_yticks([])
        return a

    def panel(self, x, y, w, h, img, cmap=None, vmin=None, vmax=None,
              frame=True, aspect="auto"):
        a = self._axes(x, y, w, h)
        a.imshow(img, cmap=cmap, vmin=vmin, vmax=vmax, aspect=aspect,
                 interpolation="nearest")
        for s in a.spines.values():
            s.set_visible(frame); s.set_color(RULE); s.set_linewidth(0.6)
        return a

    def blank(self, x, y, w, h, z=4):
        a = self._axes(x, y, w, h, z)
        for s in a.spines.values():
            s.set_visible(False)
        a.patch.set_alpha(0)
        return a

    def save(self, name):
        self.fig.savefig(f"{FIG}/{name}.png", dpi=600)
        self.fig.savefig(f"{FIG}/{name}.pdf")
        plt.close(self.fig)
        return f"{FIG}/{name}.png"


def load():
    with open(CACHE, "rb") as f:
        return pickle.load(f)


# =============================================================== Fig. 1
def fig01(d, name="fig01_overview"):
    s = d["samp"]
    snaps = s["snap"]
    ts = sorted(snaps)
    sh = Sheet(6.5, 4.55)                                   # 130 x 91 units

    sh.head(2.0, 89.0, "Reverse sampling on the spectral-subspace "
            r"coefficients $\mathbf{U}_t$  ($\mathbf{Z}_t=\mathbf{E}\mathbf{U}_t$)")
    sh.t(2.0, 83.6, "Every step: denoise (a), project (b), guide (d).    "
         r"Refresh step ($t\ \mathrm{mod}\ M=0$): also re-solve "
         r"$\Gamma$, $\mathbf{m}$ and $\mathbf{R}$ by (c).", va="top",
         fontsize=8.0)

    pw = 17.0
    xs = [103.0, 78.0, 53.0, 28.0]
    fin = stretch(s["final"]["Z"])
    for x, t in zip(xs, ts):
        im = stretch(snaps[t]["before"])
        sh.panel(x, 60.0, pw, pw, im)
        sh.t(x + pw / 2, 58.6, rf"$\mathbf{{Z}}^{{({t})}}$", ha="center",
             va="top", fontsize=8.4)
        sh.t(x + pw / 2, 54.8, rf"$\sigma={snaps[t]['sigma']:.2f}$",
             ha="center", va="top", **SM)
        sh.t(x + pw / 2, 51.4, "RMS to output "
             f"{float(np.sqrt(((im - fin) ** 2).mean())):.3f}", ha="center",
             va="top", fontsize=6.8)
    for x in xs:
        sh.arrow((x - 1.0, 68.5), (x - 7.0, 68.5), lw=1.3)
    sh.panel(3.0, 60.0, pw, pw, fin)
    sh.t(11.5, 58.6, r"$\widehat{\mathbf{Z}}$", ha="center", va="top",
         fontsize=8.4)
    sh.t(11.5, 54.8, "output", ha="center", va="top", **SM)

    sh.ax.plot([2, 128], [48.0, 48.0], color=SOFT, lw=0.8, zorder=0)
    sh.head(2.0, 46.0, "One step in full")

    bx, bw, by, bh = [2.0, 34.0, 66.0, 98.0], 30.0, 1.5, 38.0
    heads = ["(a)  Prior\n       denoising",
             "(b)  Range–null\n       projection",
             "(c)  Correspondence\n       matching",
             "(d)  Structure\n       guidance"]
    for x, h in zip(bx, heads):
        sh.box(x, by, bw, bh, fc=FILL, ec=RULE, lw=0.9)
        sh.head(x + 1.2, by + bh - 1.4, h, fontsize=8.4)

    # (a)
    st = s["stage"]["pd"]
    sh.panel(bx[0] + 1.8, 17.0, 12.0, 12.0, stretch(st["noisy"]))
    sh.panel(bx[0] + 16.2, 17.0, 12.0, 12.0, stretch(st["denoised"]))
    sh.arrow((bx[0] + 14.3, 23.0), (bx[0] + 15.9, 23.0), lw=1.0)
    sh.t(bx[0] + 7.8, 15.6, r"$\mathbf{U}_t$", ha="center", va="top",
         fontsize=8.2)
    sh.t(bx[0] + 22.2, 15.6, r"$\widehat{\mathbf{U}}_{0|t}$", ha="center",
         va="top", fontsize=8.2)
    sh.t(bx[0] + 1.6, 11.6, "frozen prior " + r"$\epsilon_\varphi$;" "\n"
         "no HR-HSI needed", va="top", **SM)

    # (b)
    st = s["stage"]["rnp"]
    for k, (im, lab) in enumerate((
            (st["rng"], r"range: $\mathbf{E}^{\top}\mathbf{X}\mathbf{H}^{+}$"),
            (st["null"], "null component"),
            (st["total"], r"sum: $\mathcal{P}_{\mathbf{X}}(\widehat{\mathbf{U}}_0)$"))):
        sh.panel(bx[1] + 1.8, 24.0 - k * 7.5, 7.0, 7.0, stretch(im))
        sh.t(bx[1] + 9.6, 27.5 - k * 7.5, lab, va="center", **SM)
    sh.t(bx[1] + 1.6, 7.6, r"$\mathbf{Z}\mathbf{H}=\mathbf{E}\mathbf{E}^{\top}"
         r"\mathbf{X}$ exactly;" "\n"
         r"here $e_{\mathrm{LR}}=%.1f\times10^{-3}$" % (s["final"]["eLR"] * 1e3),
         va="top", **SM)

    # (c)
    st = s["stage"]["pcm"]
    sh.panel(bx[2] + 1.8, 18.5, 11.5, 11.5,
             stretch(d["match"]["ref_rgb"], joint=True))
    sh.t(bx[2] + 7.5, 17.2, "reference " + r"$\mathbf{Y}$", ha="center",
         va="top", **SM)
    sh.panel(bx[2] + 16.5, 18.5, 11.5, 11.5, st["mp"], cmap=SEQ, vmin=0, vmax=1)
    sh.t(bx[2] + 22.2, 17.2, "reliability " + r"$\mathbf{m}$", ha="center",
         va="top", **SM)
    sh.t(bx[2] + 1.6, 13.5, "unbalanced transport\n"
         "leaves mass unassigned;\nthat mass is "
         r"$\mathbf{m}$" ", so no\nchange detector is needed",
         va="top", **SM)

    # (d)
    st = s["stage"]["sg"]
    sh.panel(bx[3] + 1.8, 17.0, 12.0, 12.0, stretch(st["before"]))
    sh.panel(bx[3] + 16.2, 17.0, 12.0, 12.0, stretch(st["after"]))
    sh.arrow((bx[3] + 14.3, 23.0), (bx[3] + 15.9, 23.0), lw=1.0)
    sh.t(bx[3] + 7.8, 15.6, "before", ha="center", va="top", **SM)
    sh.t(bx[3] + 22.2, 15.6, "after", ha="center", va="top", **SM)
    sh.t(bx[3] + 1.6, 11.6, "acts on the null space\nonly (Cor. 1), then a\n"
         "DDIM update", va="top", **SM)

    for i in range(3):
        sh.arrow((bx[i] + bw + 0.4, 22.0), (bx[i + 1] - 0.4, 22.0), lw=1.2)
    return sh.save(name)


# =============================================================== Fig. 2
def fig02(d, name="fig02_matching"):
    m = d["match"]
    sh = Sheet(6.5, 3.35)                                   # 130 x 67
    xs = [1.5, 27.2, 52.9, 78.6, 104.3]
    w = 24.2
    heads = ["(a)  Region\n       graphs", "(b)  Invariant\n       features",
             "(c)  GNN\n       encoder", "(d)  Unbalanced\n       transport",
             "(e)  Reliability"]
    for x, h in zip(xs, heads):
        sh.box(x, 1.5, w, 64.0, fc="white", ec=SOFT, lw=0.7)
        sh.head(x + 1.0, 64.6, h, fontsize=8.4)

    # ---- (a)
    x = xs[0]
    a = sh.panel(x + 1.4, 41.0, 11.0, 11.0, stretch(m["target_rgb"], joint=True))
    p, e = m["p"], m["edges"]
    sel = e[np.random.default_rng(0).choice(len(e), 300, replace=False)]
    a.plot([p[sel[:, 0], 1], p[sel[:, 1], 1]],
           [p[sel[:, 0], 0], p[sel[:, 1], 0]], color=BLUE, lw=0.22, alpha=0.9)
    a.scatter(p[:, 1], p[:, 0], s=0.4, color=BLUE, linewidths=0)
    a.set_xlim(0, m["target_rgb"].shape[1])
    a.set_ylim(m["target_rgb"].shape[0], 0)
    sh.t(x + 13.2, 46.5, "target\n" rf"$\mathcal{{G}}_T$: {m['n_target']}"
         "\nregions", va="center", **SM)
    sh.arrow((x + 6.9, 40.2), (x + 6.9, 36.0), lw=1.0)
    sh.panel(x + 1.4, 23.5, 11.0, 11.0, stretch(m["ref_rgb"], joint=True))
    sh.t(x + 13.2, 29.0, "reference\npyramid\n"
         rf"$\mathcal{{G}}_Y$: {m['n_ref']}" "\nnodes", va="center", **SM)
    sh.t(x + 1.2, 20.0, "SLIC regions;\nthe reference\ngraph and its\n"
         "ANN index are\nbuilt once", va="top", **SM)

    # ---- (b)
    x = xs[1]
    b = sh.blank(x + 0.8, 38.0, 22.6, 22.0)
    b.set_xlim(0, 11); b.set_ylim(0, 10.5)
    b.add_patch(Circle((3.1, 4.6), 2.3, fill=False, ec=RULE, lw=0.8))
    b.add_patch(Circle((8.0, 5.9), 1.8, fill=False, ec=RULE, lw=0.8))
    b.plot([3.1, 8.0], [4.6, 5.9], color=INK, lw=0.9)
    b.annotate("", xy=(4.3, 6.8), xytext=(3.1, 4.6),
               arrowprops=dict(arrowstyle="-|>", color=INK, lw=0.9))
    b.annotate("", xy=(9.1, 7.6), xytext=(8.0, 5.9),
               arrowprops=dict(arrowstyle="-|>", color=INK, lw=0.9))
    b.scatter([3.1, 8.0], [4.6, 5.9], s=9, color=INK, zorder=5)
    for xx, yy, s_, ha in ((3.1, 1.6, r"$\mathbf{p}_i,\ s_i$", "center"),
                           (8.3, 3.3, r"$\mathbf{p}_{i'},\ s_{i'}$", "center"),
                           (4.9, 7.5, r"$\theta_i$", "center"),
                           (9.7, 8.4, r"$\theta_{i'}$", "center"),
                           (5.6, 4.2, r"$\varphi_{ii'}$", "center")):
        b.text(xx, yy, s_, ha=ha, va="center", fontsize=8.0, color=INK)
    sh.t(x + 1.2, 36.5, "node: rotation-\ncanonicalised,\ncontrast-\n"
         "normalised patch", va="top", **SM)
    sh.t(x + 1.2, 20.5, "edge: the\ntranslation-,\nrotation- and\n"
         "scale-invariant\nvector of (4)", va="top", **SM)

    # ---- (c)
    x = xs[2]
    c = sh.blank(x + 0.8, 30.0, 22.6, 30.0)
    c.set_xlim(0, 10); c.set_ylim(0, 10)
    rng = np.random.default_rng(3)
    for yy, col in ((7.8, BLUE), (2.2, ORANGE)):
        q = rng.uniform([1.0, yy - 1.0], [9.0, yy + 1.0], size=(9, 2))
        for i in range(len(q)):
            for j in range(i + 1, len(q)):
                if np.hypot(*(q[i] - q[j])) < 3.2:
                    c.plot(*zip(q[i], q[j]), color=col, lw=0.45, alpha=0.9)
        c.scatter(q[:, 0], q[:, 1], s=9, color=col, linewidths=0, zorder=4)
    for k in range(4):
        c.annotate("", xy=(2.2 + 1.9 * k, 3.4), xytext=(2.2 + 1.9 * k, 6.6),
                   arrowprops=dict(arrowstyle="<->", color=RULE, lw=0.5,
                                   linestyle=(0, (2, 2))))
    sh.t(x + 12.0, 57.0, "target graph", ha="center", **SM)
    sh.t(x + 12.0, 31.5, "reference graph", ha="center", **SM)
    sh.t(x + 1.2, 28.5, r"$L=3$ blocks of", va="top", **SM)
    sh.t(x + 1.2, 25.0, "edge-biased self-\nand cross-attention\n"
         "over ANN\ncandidates, (5)", va="top", **SM)
    sh.t(x + 1.2, 10.5, "output: descriptors\n"
         r"$\mathbf{h}_i$ and $\mathbf{g}_j$", va="top", **SM)

    # ---- (d)
    x = xs[3]
    # the candidate restriction makes the cost sparse: pairs outside a node's
    # candidate set are never scored, and are drawn blank rather than as zero
    C = np.where(m["C"] > 0, m["C"], np.nan)
    cm = SEQ.copy(); cm.set_bad("#f0efec")
    sh.panel(x + 1.4, 45.0, 9.6, 9.6, C, cmap=cm, vmin=0.0,
             vmax=float(np.nanpercentile(C, 92)))
    sh.t(x + 6.2, 43.8, "cost " + r"$C_{ij}$" + " on\ncandidate pairs",
         ha="center", va="top", fontsize=6.8, linespacing=1.25)
    G = m["Gsub"]
    Gn = G / max(G.max(), 1e-12)
    dust = m["dust"][:, None]
    dust = dust / max(dust.max(), 1e-12)
    sh.panel(x + 13.2, 45.0, 8.0, 9.6, Gn, cmap=SEQ, vmin=0, vmax=0.22)
    sh.panel(x + 21.5, 45.0, 1.4, 9.6, dust, cmap="Greys", vmin=0, vmax=1.3)
    sh.t(x + 17.2, 43.8, r"$\Gamma$", ha="center", va="top", **SM)
    sh.t(x + 22.2, 43.8, "dust-\nbin", ha="center", va="top", fontsize=6.6,
         linespacing=1.2)
    sh.box(x + 1.4, 30.0, 21.4, 10.0, fc=FILL2, ec=RULE, lw=0.7)
    sh.t(x + 12.1, 35.0, "unbalanced\nSinkhorn scaling, (8)", ha="center",
         va="center", **SM)
    sh.t(x + 1.2, 27.0, r"$\varepsilon=0.1$, $\tau=0.15$", va="top", **SM)
    sh.t(x + 1.2, 22.5, "a region whose best\ncost is high keeps\n"
         "its mass instead of\nspending it", va="top", **SM)

    # ---- (e)
    x = xs[4]
    sh.panel(x + 1.4, 45.0, 10.4, 10.4, m["mp"], cmap=SEQ, vmin=0, vmax=1)
    sh.t(x + 6.6, 43.8, "computed " + r"$\mathbf{m}$", ha="center", va="top",
         fontsize=6.8)
    sh.panel(x + 12.6, 45.0, 10.4, 10.4, (~m["nc"]).astype(float),
             cmap="Greys_r", vmin=0, vmax=1)
    sh.t(x + 17.8, 43.8, "true mask", ha="center", va="top", fontsize=6.8)
    sh.t(x + 12.4, 40.6, "white: a counterpart exists", ha="center", va="top",
         fontsize=6.6)
    from sklearn.metrics import roc_curve, roc_auc_score
    y = m["nc"].ravel(); sc = 1.0 - m["mp"].ravel()
    fpr, tpr, _ = roc_curve(y, sc)
    pauc = roc_auc_score(y, sc)
    r = sh.blank(x + 2.4, 19.0, 10.5, 10.5)
    for s_ in r.spines.values():
        s_.set_visible(True); s_.set_color(RULE); s_.set_linewidth(0.5)
    r.spines["top"].set_visible(False); r.spines["right"].set_visible(False)
    r.plot(fpr, tpr, color=INK, lw=1.0)
    r.plot([0, 1], [0, 1], color=SOFT, lw=0.6, ls=(0, (2, 2)))
    r.set_xlim(0, 1); r.set_ylim(0, 1)
    r.set_xticks([0, 1]); r.set_yticks([0, 1])
    r.tick_params(labelsize=6.4, length=1.6, pad=1.0, colors=INK)
    sh.t(x + 7.6, 16.5, "false positive rate", ha="center", va="top",
         fontsize=6.6)
    sh.t(x + 14.4, 24.5, f"pixel\nAUROC\n{pauc:.3f}", va="center", **SM)
    sh.t(x + 1.2, 12.5, "mean " + r"$\mathbf{m}$" + ": "
         f"{m['mp'][~m['nc']].mean():.2f} where a\n"
         f"counterpart exists,\n{m['mp'][m['nc']].mean():.2f} where none does",
         va="top", **SM)
    return sh.save(name)


# =============================================================== Fig. 3
def fig03(d, name="fig03_training"):
    t = d["train"]
    # the multispectral bands are ordered blue, green, red, NIR, so the first
    # three have to be reversed before they are shown as RGB
    def view(k):
        return stretch(t[k][..., ::-1], joint=True)

    sh = Sheet(6.5, 3.35)                                   # 130 x 67
    xs, ws = [1.5, 45.0, 88.5], [42.5, 42.5, 40.0]
    heads = ["(a)  Two views of one\n       unlabelled MSI tile",
             "(b)  Partial ground truth\n       and a shared encoder",
             "(c)  What each objective\n       asks for"]
    for x, w, h in zip(xs, ws, heads):
        sh.box(x, 1.5, w, 64.0, fc="white", ec=SOFT, lw=0.7)
        sh.head(x + 1.0, 64.6, h, fontsize=8.4)

    # ---- (a) two views
    x = xs[0]
    sh.panel(x + 1.5, 42.0, 11.0, 11.0, view("src"))
    sh.t(x + 7.0, 40.6, "tile " + r"$I$", ha="center", va="top", fontsize=7.2)
    sh.box(x + 15.5, 46.0, 10.5, 5.0, fc=FILL2, ec=RULE, lw=0.6)
    sh.t(x + 20.7, 48.5, "tone curves,\nblur", ha="center", va="center",
         fontsize=6.8, linespacing=1.25)
    sh.arrow((x + 12.8, 49.0), (x + 15.2, 48.8), lw=0.9)
    sh.arrow((x + 26.2, 48.8), (x + 28.7, 49.0), lw=0.9)
    sh.panel(x + 29.0, 43.5, 11.0, 11.0, view("v1"))
    sh.t(x + 34.5, 42.1, "view " + r"$V_1$", ha="center", va="top",
         fontsize=7.2)

    sh.box(x + 15.5, 29.5, 10.5, 7.0, fc=FILL2, ec=RULE, lw=0.6)
    sh.t(x + 20.7, 33.0, "known warp\n" + r"$W$" + ", then\n"
         + r"$J$" + " under " + r"$M$", ha="center", va="center",
         fontsize=6.8, linespacing=1.25)
    sh.arrow((x + 12.8, 45.0), (x + 15.2, 35.0), lw=0.9, rad=0.12)
    sh.arrow((x + 26.2, 33.0), (x + 28.7, 31.0), lw=0.9)
    sh.panel(x + 29.0, 25.0, 11.0, 11.0, view("v2"))
    sh.t(x + 34.5, 23.6, "view " + r"$V_2$", ha="center", va="top",
         fontsize=7.2)

    sh.panel(x + 1.5, 26.5, 6.0, 6.0, view("un"))
    sh.t(x + 4.5, 25.2, "scene " + r"$J$", ha="center", va="top", fontsize=6.8)
    sh.panel(x + 8.8, 26.5, 6.0, 6.0, t["mask"].astype(float), cmap="Greys")
    sh.t(x + 11.8, 25.2, "mask " + r"$M$", ha="center", va="top", fontsize=6.8)
    sh.t(x + 1.2, 20.0,
         "one tile, two views. The warp is\n"
         "known, so which regions correspond\n"
         "and which do not is known, with no\n"
         "hyperspectral ground truth anywhere.",
         va="top", fontsize=7.2, linespacing=1.5)

    # ---- (b) partial ground truth and the shared encoder
    x = xs[1]
    a = sh.panel(x + 1.5, 38.0, 16.0, 16.0, view("v1"))
    p1, mm = t["p1"], t["matched"]
    a.scatter(p1[mm, 1], p1[mm, 0], s=7.0, facecolors="none", edgecolors=AQUA,
              linewidths=0.65)
    a.scatter(p1[~mm, 1], p1[~mm, 0], s=12.0, marker="x", color=ORANGE,
              linewidths=0.85)
    a.set_xlim(0, t["v1"].shape[1]); a.set_ylim(t["v1"].shape[0], 0)
    sh.ax.add_patch(Circle((x + 19.6, 50.0), 0.75, fc="none", ec=AQUA, lw=0.9))
    sh.t(x + 21.2, 50.0, f"{int(mm.sum())} matched", va="center", fontsize=7.2)
    sh.t(x + 21.2, 47.0, r"($\mathcal{M}$)", va="center", fontsize=7.2)
    sh.ax.plot([x + 19.1, x + 20.1], [42.5, 43.5], color=ORANGE, lw=1.0)
    sh.ax.plot([x + 19.1, x + 20.1], [43.5, 42.5], color=ORANGE, lw=1.0)
    sh.t(x + 21.2, 43.0, f"{int((~mm).sum())} unmatched", va="center",
         fontsize=7.2)
    sh.t(x + 21.2, 40.0, r"($\mathcal{U}$)", va="center", fontsize=7.2)

    yb = 31.5
    for k, lab in enumerate((r"GNN $f_\theta$ on $V_1$", r"GNN $f_\theta$ on $V_2$")):
        sh.box(x + 1.5, yb - k * 9.0, 18.0, 5.5, fc=FILL2, ec=RULE, lw=0.7)
        sh.t(x + 10.5, yb + 2.75 - k * 9.0, lab, ha="center", va="center",
             fontsize=7.4)
    sh.t(x + 10.5, 29.7, "one set of weights", ha="center", va="center",
         fontsize=7.0)
    sh.box(x + 23.5, 25.5, 17.5, 5.5, fc=FILL2, ec=RULE, lw=0.7)
    sh.t(x + 32.2, 28.2, "unrolled FUGW,\n" + r"$L_s$ iterations",
         ha="center", va="center", fontsize=7.2, linespacing=1.25)
    sh.arrow((x + 19.8, 33.5), (x + 23.2, 29.5), lw=0.9, rad=0.1)
    sh.arrow((x + 19.8, 25.5), (x + 23.2, 27.5), lw=0.9, rad=0.1)
    sh.t(x + 1.2, 20.0,
         "the encoder is trained through the\n"
         "solver that runs at inference, so its\n"
         "descriptors are fitted to the problem\n"
         "they will actually face.",
         va="top", fontsize=7.2, linespacing=1.5)

    # ---- (c) the two assignment targets
    x = xs[2]
    n_m, n_u = 9, 4
    n = n_m + n_u
    info = np.zeros((n, n + 1)); unb = np.zeros((n, n + 1))
    rng = np.random.default_rng(1)
    for i in range(n_m):
        info[i, i] = 1.0; unb[i, i] = 1.0
    for i in range(n_m, n):
        info[i, int(rng.integers(0, n_m))] = 1.0
        unb[i, n] = 1.0
    for k, (Mx, lab, note) in enumerate((
            (info, "InfoNCE target",
             "every anchor must\nbe assigned, so an\nunmatched region is\n"
             "pulled towards a\nwrong positive"),
            (unb, "TPC target (ours)",
             "unmatched regions\ngo to the dustbin,\nmatched ones to\n"
             "their true partner"))):
        yy = 43.0 - k * 21.0
        a = sh.panel(x + 1.5, yy, 13.0, 12.0, Mx, cmap="Greys", vmin=0, vmax=1.4)
        a.axvline(n - 0.5, color=RULE, lw=0.8)
        a.axhline(n_m - 0.5, color=RULE, lw=0.8)
        sh.t(x + 8.0, yy + 12.8, lab, ha="center", va="bottom", fontsize=7.6)
        sh.t(x + 14.9, yy + 8.6, r"$\mathcal{M}$", va="center", fontsize=7.4)
        sh.t(x + 14.9, yy + 2.4, r"$\mathcal{U}$", va="center", fontsize=7.4)
        sh.t(x + 13.8, yy - 1.2, "dustbin", ha="center", va="top", fontsize=6.6)
        sh.t(x + 18.6, yy + 6.0, note, va="center", fontsize=7.0,
             linespacing=1.45)
    sh.t(x + 1.2, 15.0,
         r"$\mathcal{L}_{\mathrm{TPC}}=\mathcal{L}_{\mathrm{match}}"
         r"+\beta\,\mathcal{L}_{\mathrm{rel}}$",
         va="top", fontsize=7.6)
    sh.t(x + 1.2, 10.5, "see (14) and Proposition 3", va="top", fontsize=7.2)
    return sh.save(name)


def main():
    from .paths import ensure
    ensure()
    rc()
    d = load()
    print("Fig. 1:", fig01(d))
    print("Fig. 2:", fig02(d))
    print("Fig. 3:", fig03(d))


if __name__ == "__main__":
    main()
