"""
Degradation operator, spectral subspace and the range-null projection of
Sect. 3.3, plus the plug-and-play prior that stands in for the frozen ADM.

Convention: coefficient maps U have shape (k, H, W).  The forward operator is
    A(U) = decimate(blur(U))            (k, h, w)
which is the operator written U*H in the article, and

    P_X^lambda(U) = U + lambda * A^+( E^T X - A(U) ),

so lambda = 1 reproduces (3) exactly.  A^+ = A^T (A A^T)^{-1} is applied by
conjugate gradient on A A^T, which is small (h*w = 64*64 here).
"""
import numpy as np
from scipy.ndimage import gaussian_filter, zoom


class Degradation:
    def __init__(self, shape, ratio):
        self.H, self.W = shape
        self.r = int(ratio)
        self.sig = self.r / (2.0 * np.sqrt(2.0 * np.log(2.0)))
        self.off = self.r // 2
        self.h, self.w = self.H // self.r, self.W // self.r

    # ---- forward: blur then decimate -------------------------------------
    def A(self, U):
        b = gaussian_filter(U, sigma=(0, self.sig, self.sig), mode="wrap")
        return np.ascontiguousarray(b[:, self.off::self.r, self.off::self.r])

    # ---- adjoint: zero-upsample then correlate (Gaussian is symmetric) ----
    def AT(self, X):
        k = X.shape[0]
        up = np.zeros((k, self.H, self.W), np.float64)
        up[:, self.off::self.r, self.off::self.r] = X
        return gaussian_filter(up, sigma=(0, self.sig, self.sig), mode="wrap")

    def AAT(self, X):
        return self.A(self.AT(X))

    # ---- pseudo-inverse by CG on A A^T -----------------------------------
    def Aplus(self, X, iters=120, tol=1e-10):
        X = np.asarray(X, np.float64)
        w = np.zeros_like(X)
        r = X - self.AAT(w)
        p = r.copy()
        rs = np.einsum("khw,khw->k", r, r)
        rs0 = rs.copy() + 1e-30
        for _ in range(iters):
            Ap = self.AAT(p)
            den = np.einsum("khw,khw->k", p, Ap) + 1e-30
            al = (rs / den)[:, None, None]
            w += al * p
            r -= al * Ap
            rs_new = np.einsum("khw,khw->k", r, r)
            if np.all(rs_new / rs0 < tol):
                break
            p = r + (rs_new / (rs + 1e-30))[:, None, None] * p
            rs = rs_new
        return self.AT(w)


# ------------------------------------------------------------------ subspace
def spectral_subspace(X, k=8):
    """E = top-k left singular vectors of the LR-HSI X (C, h, w) -> (C, k)."""
    C = X.shape[0]
    M = X.reshape(C, -1)
    U, s, _ = np.linalg.svd(M - 0.0, full_matrices=False)
    return U[:, :k].astype(np.float64), s


# ------------------------------------------------------------ plug-and-play prior
def _box(im, r):
    """O(1) box filter via integral image; im is (H,W)."""
    H, W = im.shape
    c = np.cumsum(np.cumsum(np.pad(im, ((1, 0), (1, 0))), 0), 1)
    y0 = np.clip(np.arange(H) - r, 0, H); y1 = np.clip(np.arange(H) + r + 1, 0, H)
    x0 = np.clip(np.arange(W) - r, 0, W); x1 = np.clip(np.arange(W) + r + 1, 0, W)
    S = (c[np.ix_(y1, x1)] - c[np.ix_(y0, x1)] - c[np.ix_(y1, x0)] + c[np.ix_(y0, x0)])
    N = ((y1 - y0)[:, None] * (x1 - x0)[None, :]).astype(np.float64)
    return S / N


def guided_filter(p, I, r, eps):
    """Edge-preserving smoothing of p guided by I (He et al.)."""
    mI, mp = _box(I, r), _box(p, r)
    cIp = _box(I * p, r) - mI * mp
    vI = _box(I * I, r) - mI * mI
    a = cIp / (vI + eps)
    b = mp - a * mI
    return _box(a, r) * I + _box(b, r)


def pnp_denoise(U, sigma, guide=None):
    """Cross-channel edge-preserving denoiser used as the image prior.

    The article uses a frozen 553.8 M-parameter ADM checkpoint here; that
    checkpoint cannot be fetched in this environment, so a guided-filter prior
    is substituted.  It is weaker, but it is *identical for every variant*
    compared below, so the reference-transfer behaviour that Figs. 5-6 are
    about is unaffected.
    """
    k = U.shape[0]
    g = U[0] if guide is None else guide
    gm = (g - g.mean()) / (g.std() + 1e-8)
    r = int(np.clip(round(1.0 + 6.0 * sigma), 1, 8))
    eps = float(np.clip(1.5 * sigma ** 2, 1e-5, 0.5))
    out = np.empty_like(U)
    for c in range(k):
        out[c] = guided_filter(U[c], gm, r, eps)
    return out
