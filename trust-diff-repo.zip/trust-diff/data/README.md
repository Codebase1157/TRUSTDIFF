# Data

No cube is redistributed here. Each is public; download it from the source
below and place it exactly as shown.

```
data/
  houston/data.mat              Houston 2013, CASI, 349 x 1905 x 144, 380-1050 nm
  pavia/PaviaU.mat              Pavia University, ROSIS, 610 x 340 x 103, 430-860 nm
  indian/indianpinearray.npy    Indian Pines, AVIRIS, 145 x 145 x 200
  indian/IPgt.npy               Indian Pines 16-class ground truth
```

| Scene | Source | Used for |
| --- | --- | --- |
| Houston 2013 | 2013 IEEE GRSS Data Fusion Contest, distributed by the IEEE GRSS Image Analysis and Data Fusion Technical Committee | target and reference windows, CNC-Bench |
| Pavia University | Telecommunications and Remote Sensing Laboratory, Pavia University (ROSIS); mirrored by the Computational Intelligence Group, UPV/EHU | target and reference windows, unrelated content for CNC-Bench |
| Indian Pines | Purdue University Research Repository, doi:10.4231/R7RX991C | downstream classification only |

`data.mat` must contain a variable `data`; `PaviaU.mat` a variable `paviaU`.
Both are `(rows, cols, bands)`. Indian Pines is supplied as two `.npy` arrays.

Set `TRUSTDIFF_DATA` to point elsewhere if you keep the cubes outside the
checkout.

Each dataset is governed by the terms of its provider; check them before
redistributing anything derived from them.
